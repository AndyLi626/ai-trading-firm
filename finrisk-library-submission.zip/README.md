# FinRisk Library

FinRisk Library is a clean-room Java 17 Maven project that demonstrates the architecture of a production-minded financial analytics library. It supports valuation and common risk measures for four asset classes:

- Rates
- FX
- Credit
- Mortgages

The implementation is intentionally small. Pricing formulas are illustrative only; the goal is to show clear contracts, routing, validation, traceability, scenario revaluation, and regression comparison without over-engineering the assignment.

## Build And Test

```bash
mvn test
```

## Package

The Java package root is:

```text
com.example.finrisk
```

The main package responsibilities are:

- `api`: immutable request/result facade contracts.
- `domain`: common trade, valuation, measure, and pricing context models.
- `instrument`: product definitions for rates, FX, credit, and mortgages.
- `market`: read-only market data snapshot and in-memory demo implementation.
- `pricing`: stateless pricers, pricer registry, and default library facade.
- `risk`: scenario revaluation and regression comparison utilities.
- `validation`: request and market data completeness checks.
- `audit`: calculation trace metadata.

## Core Abstractions

`CalculationRequest` is an immutable Java record containing request id, valuation date, market data set id, model version, scenario id, and requested measures.

`Trade` wraps a product, quantity, and book. Products implement `Product` and declare their asset class, product type, and minimum market data requirements.

`MarketDataSnapshot` is the only market data access boundary used by pricers. The demo implementation is `InMemoryMarketDataSnapshot`; there is no database, REST API, queue, or publisher dependency in the core library.

`TradePricer` is the stateless pricing contract. `PricerRegistry` routes each product to the correct pricer. The default registry includes:

- `RatesSwapPricer`
- `FxForwardPricer`
- `CreditDefaultSwapPricer`
- `MortgagePoolPricer`

`DefaultFinancialLibrary` is the top-level orchestration facade. It validates the request, builds pricing context, resolves pricers through the registry, collects trade-level results, and returns normalized valuations.

`CalculationTrace` captures request id, valuation date, market data set id, model version, scenario id, pricer name, and calculation timestamp for auditability.

## Flow

```text
CalculationRequest
  -> MarketDataSnapshot validation
  -> PricerRegistry routing
  -> stateless TradePricer calculation
  -> TradeValuation result
  -> CalculationTrace audit metadata
  -> optional ScenarioRiskCalculator / ResultComparator controls
```

## Supported Measures

- `PRESENT_VALUE`
- `DV01`
- `FX_DELTA`
- `CS01`
- `OAS`

The measures are returned where they are relevant to the product type. A portfolio containing all four demo asset classes can return the full requested measure set.

## Scenario Risk

`ScenarioRiskCalculator` performs simple bumped revaluation. It calculates base PV, applies a market data bump to an in-memory snapshot, revalues the trades, and returns trade-level PV differences for a named scenario. This is enough to demonstrate how DV01- or CS01-style risk can be produced through revaluation instead of embedding scenario logic inside pricers.

## Regression Comparison

`ResultComparator` compares baseline and candidate `CalculationResult` instances using a numeric tolerance. This is a lightweight control useful for model upgrades, refactoring, and release checks.

## Why This Is Production-Minded

- Immutable request/result models use Java records.
- Pricers are stateless and isolated by product type.
- Market data is accessed only through `MarketDataSnapshot`.
- Validation failures are explicit and returned before pricing starts.
- Audit trace fields support reproducibility and model governance.
- Scenario risk is implemented through revaluation, keeping pricers simple.
- Regression comparison is included as a first-class engineering control.
- The core library has no database, REST, queue, or vendor dependency.

## Intentionally Out Of Scope

- Full financial model calibration.
- Real curve construction and interpolation.
- Complete product lifecycle events.
- Database persistence.
- REST/gRPC API layer.
- Queue, staging, or publisher implementation.
- Distributed compute and caching.

These concerns can be added around the core contracts without changing the pricing path.
