# Roadmap

## Phase 0: Review-Ready Skeleton

Goal: demonstrate clean architecture, extensibility, and production controls in a compact Java 17 Maven project.

Included:

- Immutable request/result records.
- Rates, FX, credit, and mortgage product examples.
- Stateless pricers behind a shared `TradePricer` contract.
- `PricerRegistry` routing.
- `MarketDataSnapshot` boundary.
- Validation, traceability, scenario risk, and regression comparison.
- JUnit tests for the required behaviors.

## Phase 1: Analytics Depth

Add richer model implementations while preserving the public contracts:

- Curve interpolation and discounting conventions.
- Schedule generation and day-count handling.
- FX forwards with discount curves.
- Credit survival curves and recovery assumptions.
- Mortgage cashflow and prepayment model hooks.

## Phase 2: Model Governance

Add controls expected in production model environments:

- Model selection policy.
- Versioned model configuration.
- Explain payloads for valuation lineage.
- Structured validation diagnostics.
- Golden-copy regression packs.

## Phase 3: Performance

Improve runtime characteristics without changing pricer semantics:

- Portfolio partitioning.
- Market data snapshot reuse.
- Sensitivity batching.
- Benchmark profiles.
- Memory and latency limits.

## Phase 4: Integration Layer

Keep integration outside the core library:

- Batch adapters.
- Service facade if needed.
- Persistence adapters.
- Result publication adapters.
- Entitlement and operational controls.

The core library should remain usable in unit tests without infrastructure.
