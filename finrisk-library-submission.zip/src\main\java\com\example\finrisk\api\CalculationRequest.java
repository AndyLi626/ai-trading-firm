package com.example.finrisk.api;

import com.example.finrisk.domain.RiskMeasure;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Set;

public record CalculationRequest(
        String requestId,
        LocalDate valuationDate,
        String marketDataSetId,
        String modelVersion,
        String scenarioId,
        Set<RiskMeasure> requestedMeasures) {

    public CalculationRequest {
        requireText(requestId, "requestId");
        Objects.requireNonNull(valuationDate, "valuationDate");
        requireText(marketDataSetId, "marketDataSetId");
        requireText(modelVersion, "modelVersion");
        scenarioId = scenarioId == null || scenarioId.isBlank() ? "BASE" : scenarioId;
        if (requestedMeasures == null || requestedMeasures.isEmpty()) {
            throw new IllegalArgumentException("requestedMeasures must not be empty");
        }
        requestedMeasures = Set.copyOf(requestedMeasures);
    }

    public CalculationRequest withScenario(String nextScenarioId, Set<RiskMeasure> measures) {
        return new CalculationRequest(
                requestId,
                valuationDate,
                marketDataSetId,
                modelVersion,
                nextScenarioId,
                measures);
    }

    private static void requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
    }
}
