package com.example.finrisk.api;

import com.example.finrisk.domain.TradeValuation;
import com.example.finrisk.validation.ValidationResult;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

public record CalculationResult(
        CalculationRequest request,
        List<TradeValuation> valuations,
        ValidationResult validation,
        List<String> warnings) {

    public CalculationResult {
        Objects.requireNonNull(request, "request");
        valuations = List.copyOf(Objects.requireNonNull(valuations, "valuations"));
        validation = Objects.requireNonNull(validation, "validation");
        warnings = List.copyOf(Objects.requireNonNull(warnings, "warnings"));
    }

    public boolean successful() {
        return validation.isValid();
    }

    public Map<String, TradeValuation> valuationsByTradeId() {
        return valuations.stream()
                .collect(Collectors.toUnmodifiableMap(TradeValuation::tradeId, Function.identity()));
    }
}
