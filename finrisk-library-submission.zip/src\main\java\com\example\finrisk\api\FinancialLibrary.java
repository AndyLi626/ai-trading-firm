package com.example.finrisk.api;

import com.example.finrisk.domain.Trade;
import com.example.finrisk.market.MarketDataSnapshot;

import java.util.List;

public interface FinancialLibrary {

    CalculationResult calculate(
            CalculationRequest request,
            List<Trade> trades,
            MarketDataSnapshot marketDataSnapshot);
}
