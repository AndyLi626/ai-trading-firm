package com.example.finrisk.audit;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;

public record CalculationTrace(
        String requestId,
        LocalDate valuationDate,
        String marketDataSetId,
        String modelVersion,
        String scenarioId,
        String pricerName,
        Instant calculatedAt) {

    public CalculationTrace {
        requireText(requestId, "requestId");
        Objects.requireNonNull(valuationDate, "valuationDate");
        requireText(marketDataSetId, "marketDataSetId");
        requireText(modelVersion, "modelVersion");
        scenarioId = scenarioId == null || scenarioId.isBlank() ? "BASE" : scenarioId;
        requireText(pricerName, "pricerName");
        calculatedAt = calculatedAt == null ? Instant.now() : calculatedAt;
    }

    private static void requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
    }
}
