package com.example.finrisk.domain;

public enum AssetClass {
    RATES,
    FX,
    CREDIT,
    MORTGAGES
}
