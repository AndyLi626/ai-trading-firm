package com.example.finrisk.domain;

import java.time.LocalDate;

public record PricingContext(
        String requestId,
        LocalDate valuationDate,
        String marketDataSetId,
        String modelVersion,
        String scenarioId) {
}
