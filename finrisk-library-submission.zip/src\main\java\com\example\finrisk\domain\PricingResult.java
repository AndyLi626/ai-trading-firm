package com.example.finrisk.domain;

import com.example.finrisk.audit.CalculationTrace;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public record PricingResult(
        Trade trade,
        Map<RiskMeasure, Double> measures,
        CalculationTrace trace,
        List<String> warnings) {

    public PricingResult {
        Objects.requireNonNull(trade, "trade");
        measures = Map.copyOf(new LinkedHashMap<>(Objects.requireNonNull(measures, "measures")));
        Objects.requireNonNull(trace, "trace");
        warnings = List.copyOf(Objects.requireNonNull(warnings, "warnings"));
    }
}
