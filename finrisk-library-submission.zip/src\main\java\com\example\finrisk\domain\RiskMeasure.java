package com.example.finrisk.domain;

public enum RiskMeasure {
    PRESENT_VALUE,
    DV01,
    FX_DELTA,
    CS01,
    OAS
}
