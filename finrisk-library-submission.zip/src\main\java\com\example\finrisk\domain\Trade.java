package com.example.finrisk.domain;

import com.example.finrisk.instrument.Product;

import java.util.Objects;

public record Trade(
        String tradeId,
        Product product,
        double quantity,
        String book) {

    public Trade {
        if (tradeId == null || tradeId.isBlank()) {
            throw new IllegalArgumentException("tradeId must not be blank");
        }
        Objects.requireNonNull(product, "product");
        if (!Double.isFinite(quantity) || quantity == 0.0d) {
            throw new IllegalArgumentException("quantity must be a finite non-zero number");
        }
        book = book == null || book.isBlank() ? "UNASSIGNED" : book;
    }
}
