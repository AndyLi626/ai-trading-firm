package com.example.finrisk.domain;

import com.example.finrisk.audit.CalculationTrace;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public record TradeValuation(
        String tradeId,
        String productType,
        AssetClass assetClass,
        Map<RiskMeasure, Double> measures,
        CalculationTrace trace) {

    public TradeValuation {
        if (tradeId == null || tradeId.isBlank()) {
            throw new IllegalArgumentException("tradeId must not be blank");
        }
        if (productType == null || productType.isBlank()) {
            throw new IllegalArgumentException("productType must not be blank");
        }
        Objects.requireNonNull(assetClass, "assetClass");
        measures = Map.copyOf(new LinkedHashMap<>(Objects.requireNonNull(measures, "measures")));
        Objects.requireNonNull(trace, "trace");
    }

    public static TradeValuation from(PricingResult pricingResult) {
        var trade = pricingResult.trade();
        return new TradeValuation(
                trade.tradeId(),
                trade.product().productType(),
                trade.product().assetClass(),
                pricingResult.measures(),
                pricingResult.trace());
    }
}
