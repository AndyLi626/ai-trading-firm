package com.example.finrisk.instrument;

import com.example.finrisk.domain.AssetClass;
import com.example.finrisk.market.CurveId;
import com.example.finrisk.market.MarketDataRequirement;

import java.util.Set;

public record CreditDefaultSwap(
        String referenceEntity,
        CurveId creditCurve,
        CurveId discountCurve,
        double coupon,
        double maturityYears) implements Product {

    @Override
    public String productType() {
        return "CREDIT_DEFAULT_SWAP";
    }

    @Override
    public AssetClass assetClass() {
        return AssetClass.CREDIT;
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(
                MarketDataRequirement.creditSpread(creditCurve, maturityYears),
                MarketDataRequirement.discountFactor(discountCurve, maturityYears));
    }
}
