package com.example.finrisk.instrument;

import com.example.finrisk.domain.AssetClass;
import com.example.finrisk.market.MarketDataRequirement;

import java.util.Set;

public record FxForward(
        String baseCurrency,
        String quoteCurrency,
        double agreedForwardRate,
        double maturityYears) implements Product {

    public String currencyPair() {
        return baseCurrency + "/" + quoteCurrency;
    }

    @Override
    public String productType() {
        return "FX_FORWARD";
    }

    @Override
    public AssetClass assetClass() {
        return AssetClass.FX;
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(MarketDataRequirement.fxRate(currencyPair()));
    }
}
