package com.example.finrisk.instrument;

import com.example.finrisk.domain.AssetClass;
import com.example.finrisk.market.CurveId;
import com.example.finrisk.market.MarketDataRequirement;

import java.util.Set;

public record InterestRateSwap(
        String payCurrency,
        CurveId discountCurve,
        double fixedRate,
        double maturityYears) implements Product {

    @Override
    public String productType() {
        return "INTEREST_RATE_SWAP";
    }

    @Override
    public AssetClass assetClass() {
        return AssetClass.RATES;
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(MarketDataRequirement.discountFactor(discountCurve, maturityYears));
    }
}
