package com.example.finrisk.instrument;

import com.example.finrisk.domain.AssetClass;
import com.example.finrisk.market.CurveId;
import com.example.finrisk.market.MarketDataRequirement;

import java.util.Set;

public record MortgagePool(
        String poolId,
        CurveId discountCurve,
        CurveId oasCurve,
        String prepaymentModel,
        double weightedAverageLifeYears) implements Product {

    @Override
    public String productType() {
        return "MORTGAGE_POOL";
    }

    @Override
    public AssetClass assetClass() {
        return AssetClass.MORTGAGES;
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(
                MarketDataRequirement.discountFactor(discountCurve, weightedAverageLifeYears),
                MarketDataRequirement.oasSpread(oasCurve, weightedAverageLifeYears),
                MarketDataRequirement.prepaymentRate(prepaymentModel, 12));
    }
}
