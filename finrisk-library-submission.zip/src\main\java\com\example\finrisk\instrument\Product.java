package com.example.finrisk.instrument;

import com.example.finrisk.domain.AssetClass;
import com.example.finrisk.market.MarketDataRequirement;

import java.util.Set;

public interface Product {

    String productType();

    AssetClass assetClass();

    Set<MarketDataRequirement> marketDataRequirements();
}
