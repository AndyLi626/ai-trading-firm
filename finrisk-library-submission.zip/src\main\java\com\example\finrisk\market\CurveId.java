package com.example.finrisk.market;

public record CurveId(String name) {

    public CurveId {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("curve name must not be blank");
        }
    }
}
