package com.example.finrisk.market;

public record MarketDataRequirement(Type type, String key) {

    public enum Type {
        DISCOUNT_FACTOR,
        FX_RATE,
        CREDIT_SPREAD,
        OAS_SPREAD,
        PREPAYMENT_RATE
    }

    public MarketDataRequirement {
        if (type == null) {
            throw new IllegalArgumentException("type must not be null");
        }
        if (key == null || key.isBlank()) {
            throw new IllegalArgumentException("key must not be blank");
        }
    }

    public static MarketDataRequirement discountFactor(CurveId curveId, double yearFraction) {
        return new MarketDataRequirement(Type.DISCOUNT_FACTOR, curveKey(curveId, yearFraction));
    }

    public static MarketDataRequirement fxRate(String currencyPair) {
        return new MarketDataRequirement(Type.FX_RATE, currencyPair);
    }

    public static MarketDataRequirement creditSpread(CurveId curveId, double yearFraction) {
        return new MarketDataRequirement(Type.CREDIT_SPREAD, curveKey(curveId, yearFraction));
    }

    public static MarketDataRequirement oasSpread(CurveId curveId, double yearFraction) {
        return new MarketDataRequirement(Type.OAS_SPREAD, curveKey(curveId, yearFraction));
    }

    public static MarketDataRequirement prepaymentRate(String modelKey, int month) {
        return new MarketDataRequirement(Type.PREPAYMENT_RATE, modelKey + "@" + month);
    }

    public static String curveKey(CurveId curveId, double yearFraction) {
        return curveId.name() + "@" + Double.toString(yearFraction);
    }
}
