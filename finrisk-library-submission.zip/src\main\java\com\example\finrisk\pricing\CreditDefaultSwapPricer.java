package com.example.finrisk.pricing;

import com.example.finrisk.audit.CalculationTrace;
import com.example.finrisk.domain.PricingContext;
import com.example.finrisk.domain.PricingResult;
import com.example.finrisk.domain.RiskMeasure;
import com.example.finrisk.domain.Trade;
import com.example.finrisk.instrument.CreditDefaultSwap;
import com.example.finrisk.instrument.Product;
import com.example.finrisk.market.MarketDataSnapshot;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public final class CreditDefaultSwapPricer implements TradePricer {

    @Override
    public String pricerName() {
        return "CreditDefaultSwapPricer";
    }

    @Override
    public boolean supports(Product product) {
        return product instanceof CreditDefaultSwap;
    }

    @Override
    public PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context) {
        var cds = (CreditDefaultSwap) trade.product();
        var discountFactor = marketDataSnapshot.discountFactor(cds.discountCurve(), cds.maturityYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing discount factor for " + cds.discountCurve()));
        var spread = marketDataSnapshot.creditSpread(cds.creditCurve(), cds.maturityYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing credit spread for " + cds.creditCurve()));
        var presentValue = trade.quantity() * (cds.coupon() - spread) * cds.maturityYears() * discountFactor;
        var measures = new LinkedHashMap<RiskMeasure, Double>();
        if (requestedMeasures.contains(RiskMeasure.PRESENT_VALUE)) {
            measures.put(RiskMeasure.PRESENT_VALUE, presentValue);
        }
        if (requestedMeasures.contains(RiskMeasure.CS01)) {
            measures.put(RiskMeasure.CS01, -trade.quantity() * cds.maturityYears() * discountFactor * 0.0001d);
        }
        return new PricingResult(trade, measures, trace(context), List.of());
    }

    private CalculationTrace trace(PricingContext context) {
        return new CalculationTrace(
                context.requestId(),
                context.valuationDate(),
                context.marketDataSetId(),
                context.modelVersion(),
                context.scenarioId(),
                pricerName(),
                Instant.now());
    }
}
