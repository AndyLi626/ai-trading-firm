package com.example.finrisk.pricing;

import com.example.finrisk.api.CalculationRequest;
import com.example.finrisk.api.CalculationResult;
import com.example.finrisk.api.FinancialLibrary;
import com.example.finrisk.domain.PricingContext;
import com.example.finrisk.domain.Trade;
import com.example.finrisk.domain.TradeValuation;
import com.example.finrisk.market.MarketDataSnapshot;
import com.example.finrisk.validation.RequestValidator;
import com.example.finrisk.validation.ValidationResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class DefaultFinancialLibrary implements FinancialLibrary {

    private final PricerRegistry pricerRegistry;
    private final RequestValidator requestValidator;

    public DefaultFinancialLibrary(PricerRegistry pricerRegistry, RequestValidator requestValidator) {
        this.pricerRegistry = Objects.requireNonNull(pricerRegistry, "pricerRegistry");
        this.requestValidator = Objects.requireNonNull(requestValidator, "requestValidator");
    }

    public static DefaultFinancialLibrary standard() {
        return new DefaultFinancialLibrary(PricerRegistry.standard(), new RequestValidator());
    }

    @Override
    public CalculationResult calculate(
            CalculationRequest request,
            List<Trade> trades,
            MarketDataSnapshot marketDataSnapshot) {
        var validation = requestValidator.validate(request, trades, marketDataSnapshot);
        if (!validation.isValid()) {
            return new CalculationResult(request, List.of(), validation, validation.errors());
        }

        var context = new PricingContext(
                request.requestId(),
                request.valuationDate(),
                marketDataSnapshot.marketDataSetId(),
                request.modelVersion(),
                request.scenarioId());

        var valuations = new ArrayList<TradeValuation>();
        var warnings = new ArrayList<String>();
        for (Trade trade : trades) {
            var pricer = pricerRegistry.resolve(trade.product());
            var pricingResult = pricer.price(trade, marketDataSnapshot, request.requestedMeasures(), context);
            valuations.add(TradeValuation.from(pricingResult));
            warnings.addAll(pricingResult.warnings());
        }

        return new CalculationResult(request, valuations, ValidationResult.valid(), warnings);
    }
}
