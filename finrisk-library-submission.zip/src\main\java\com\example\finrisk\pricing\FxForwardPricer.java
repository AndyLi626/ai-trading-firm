package com.example.finrisk.pricing;

import com.example.finrisk.audit.CalculationTrace;
import com.example.finrisk.domain.PricingContext;
import com.example.finrisk.domain.PricingResult;
import com.example.finrisk.domain.RiskMeasure;
import com.example.finrisk.domain.Trade;
import com.example.finrisk.instrument.FxForward;
import com.example.finrisk.instrument.Product;
import com.example.finrisk.market.MarketDataSnapshot;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public final class FxForwardPricer implements TradePricer {

    @Override
    public String pricerName() {
        return "FxForwardPricer";
    }

    @Override
    public boolean supports(Product product) {
        return product instanceof FxForward;
    }

    @Override
    public PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context) {
        var forward = (FxForward) trade.product();
        var spot = marketDataSnapshot.fxRate(forward.currencyPair())
                .orElseThrow(() -> new IllegalArgumentException("Missing FX rate for " + forward.currencyPair()));
        var presentValue = trade.quantity() * (spot - forward.agreedForwardRate());
        var measures = new LinkedHashMap<RiskMeasure, Double>();
        if (requestedMeasures.contains(RiskMeasure.PRESENT_VALUE)) {
            measures.put(RiskMeasure.PRESENT_VALUE, presentValue);
        }
        if (requestedMeasures.contains(RiskMeasure.FX_DELTA)) {
            measures.put(RiskMeasure.FX_DELTA, trade.quantity());
        }
        return new PricingResult(trade, measures, trace(context), List.of());
    }

    private CalculationTrace trace(PricingContext context) {
        return new CalculationTrace(
                context.requestId(),
                context.valuationDate(),
                context.marketDataSetId(),
                context.modelVersion(),
                context.scenarioId(),
                pricerName(),
                Instant.now());
    }
}
