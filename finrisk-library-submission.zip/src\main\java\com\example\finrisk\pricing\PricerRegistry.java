package com.example.finrisk.pricing;

import com.example.finrisk.instrument.Product;

import java.util.List;
import java.util.Objects;

public final class PricerRegistry {

    private final List<TradePricer> pricers;

    public PricerRegistry(List<TradePricer> pricers) {
        if (pricers == null || pricers.isEmpty()) {
            throw new IllegalArgumentException("at least one pricer must be registered");
        }
        this.pricers = List.copyOf(pricers);
    }

    public static PricerRegistry standard() {
        return new PricerRegistry(List.of(
                new RatesSwapPricer(),
                new FxForwardPricer(),
                new CreditDefaultSwapPricer(),
                new MortgagePoolPricer()));
    }

    public TradePricer resolve(Product product) {
        Objects.requireNonNull(product, "product");
        return pricers.stream()
                .filter(pricer -> pricer.supports(product))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No pricer registered for " + product.productType()));
    }

    public List<TradePricer> registeredPricers() {
        return pricers;
    }
}
