package com.example.finrisk.pricing;

import com.example.finrisk.audit.CalculationTrace;
import com.example.finrisk.domain.PricingContext;
import com.example.finrisk.domain.PricingResult;
import com.example.finrisk.domain.RiskMeasure;
import com.example.finrisk.domain.Trade;
import com.example.finrisk.instrument.InterestRateSwap;
import com.example.finrisk.instrument.Product;
import com.example.finrisk.market.MarketDataSnapshot;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public final class RatesSwapPricer implements TradePricer {

    @Override
    public String pricerName() {
        return "RatesSwapPricer";
    }

    @Override
    public boolean supports(Product product) {
        return product instanceof InterestRateSwap;
    }

    @Override
    public PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context) {
        var swap = (InterestRateSwap) trade.product();
        var discountFactor = marketDataSnapshot.discountFactor(swap.discountCurve(), swap.maturityYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing discount factor for " + swap.discountCurve()));
        var parRate = Math.pow(1.0d / discountFactor, 1.0d / swap.maturityYears()) - 1.0d;
        var presentValue = trade.quantity() * (swap.fixedRate() - parRate) * swap.maturityYears() * discountFactor;
        var measures = new LinkedHashMap<RiskMeasure, Double>();
        if (requestedMeasures.contains(RiskMeasure.PRESENT_VALUE)) {
            measures.put(RiskMeasure.PRESENT_VALUE, presentValue);
        }
        if (requestedMeasures.contains(RiskMeasure.DV01)) {
            measures.put(RiskMeasure.DV01, trade.quantity() * swap.maturityYears() * discountFactor * 0.0001d);
        }
        return new PricingResult(trade, measures, trace(context), List.of());
    }

    private CalculationTrace trace(PricingContext context) {
        return new CalculationTrace(
                context.requestId(),
                context.valuationDate(),
                context.marketDataSetId(),
                context.modelVersion(),
                context.scenarioId(),
                pricerName(),
                Instant.now());
    }
}
