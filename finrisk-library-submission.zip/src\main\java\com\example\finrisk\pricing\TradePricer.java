package com.example.finrisk.pricing;

import com.example.finrisk.domain.PricingContext;
import com.example.finrisk.domain.PricingResult;
import com.example.finrisk.domain.RiskMeasure;
import com.example.finrisk.domain.Trade;
import com.example.finrisk.instrument.Product;
import com.example.finrisk.market.MarketDataSnapshot;

import java.util.Set;

public interface TradePricer {

    String pricerName();

    boolean supports(Product product);

    PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context);
}
