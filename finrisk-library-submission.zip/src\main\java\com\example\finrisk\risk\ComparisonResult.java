package com.example.finrisk.risk;

import java.util.List;

public record ComparisonResult(boolean withinTolerance, List<String> differences) {

    public ComparisonResult {
        differences = List.copyOf(differences);
    }
}
