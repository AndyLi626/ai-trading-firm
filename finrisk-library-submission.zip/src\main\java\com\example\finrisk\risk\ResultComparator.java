package com.example.finrisk.risk;

import com.example.finrisk.api.CalculationResult;

import java.util.ArrayList;

public final class ResultComparator {

    public ComparisonResult compare(
            CalculationResult baseline,
            CalculationResult candidate,
            double tolerance) {
        var differences = new ArrayList<String>();
        var candidateByTrade = candidate.valuationsByTradeId();
        for (var baselineValuation : baseline.valuations()) {
            var candidateValuation = candidateByTrade.get(baselineValuation.tradeId());
            if (candidateValuation == null) {
                differences.add("Missing candidate valuation for " + baselineValuation.tradeId());
                continue;
            }
            for (var measureEntry : baselineValuation.measures().entrySet()) {
                var candidateValue = candidateValuation.measures().get(measureEntry.getKey());
                if (candidateValue == null) {
                    differences.add("Missing candidate measure "
                            + measureEntry.getKey()
                            + " for "
                            + baselineValuation.tradeId());
                    continue;
                }
                var diff = Math.abs(measureEntry.getValue() - candidateValue);
                if (diff > tolerance) {
                    differences.add("Difference outside tolerance for "
                            + baselineValuation.tradeId()
                            + " "
                            + measureEntry.getKey()
                            + ": "
                            + diff);
                }
            }
        }
        return new ComparisonResult(differences.isEmpty(), differences);
    }
}
