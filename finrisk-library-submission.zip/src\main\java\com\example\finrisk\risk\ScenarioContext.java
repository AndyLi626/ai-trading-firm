package com.example.finrisk.risk;

import com.example.finrisk.domain.RiskMeasure;
import com.example.finrisk.market.CurveId;
import com.example.finrisk.market.MarketDataRequirement;

public record ScenarioContext(
        String scenarioId,
        RiskMeasure riskMeasure,
        MarketDataRequirement.Type bumpType,
        CurveId curveId,
        String fxPair,
        double bumpSize) {

    public ScenarioContext {
        if (scenarioId == null || scenarioId.isBlank()) {
            throw new IllegalArgumentException("scenarioId must not be blank");
        }
        if (riskMeasure == null) {
            throw new IllegalArgumentException("riskMeasure must not be null");
        }
        if (bumpType == null) {
            throw new IllegalArgumentException("bumpType must not be null");
        }
        if (!Double.isFinite(bumpSize) || bumpSize == 0.0d) {
            throw new IllegalArgumentException("bumpSize must be finite and non-zero");
        }
    }
}
