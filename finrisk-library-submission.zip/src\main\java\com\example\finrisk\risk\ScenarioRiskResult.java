package com.example.finrisk.risk;

import com.example.finrisk.domain.RiskMeasure;

import java.util.Map;

public record ScenarioRiskResult(
        String scenarioId,
        RiskMeasure riskMeasure,
        Map<String, Double> tradeRisk) {

    public ScenarioRiskResult {
        tradeRisk = Map.copyOf(tradeRisk);
    }
}
