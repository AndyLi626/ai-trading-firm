package com.example.finrisk.validation;

import com.example.finrisk.api.CalculationRequest;
import com.example.finrisk.domain.Trade;
import com.example.finrisk.market.MarketDataSnapshot;

import java.util.ArrayList;
import java.util.List;

public final class RequestValidator {

    public ValidationResult validate(
            CalculationRequest request,
            List<Trade> trades,
            MarketDataSnapshot marketDataSnapshot) {
        var errors = new ArrayList<String>();
        if (request == null) {
            errors.add("Calculation request is required");
        }
        if (trades == null || trades.isEmpty()) {
            errors.add("At least one trade is required");
        }
        if (marketDataSnapshot == null) {
            errors.add("Market data snapshot is required");
        }
        if (!errors.isEmpty()) {
            return ValidationResult.invalid(errors);
        }

        for (Trade trade : trades) {
            for (var requirement : trade.product().marketDataRequirements()) {
                if (!marketDataSnapshot.contains(requirement)) {
                    errors.add("Missing market data for trade "
                            + trade.tradeId()
                            + ": "
                            + requirement.type()
                            + " "
                            + requirement.key());
                }
            }
        }
        return errors.isEmpty() ? ValidationResult.valid() : ValidationResult.invalid(errors);
    }
}
