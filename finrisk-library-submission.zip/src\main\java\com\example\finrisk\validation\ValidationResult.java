package com.example.finrisk.validation;

import java.util.List;

public record ValidationResult(List<String> errors, List<String> warnings) {

    public ValidationResult {
        errors = List.copyOf(errors);
        warnings = List.copyOf(warnings);
    }

    public static ValidationResult valid() {
        return new ValidationResult(List.of(), List.of());
    }

    public static ValidationResult invalid(List<String> errors) {
        return new ValidationResult(errors, List.of());
    }

    public boolean isValid() {
        return errors.isEmpty();
    }
}
