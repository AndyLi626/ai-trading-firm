# Project Design

## Executive Summary

FinRisk Library is a clean-room Java 17 financial analytics library skeleton. It is designed to be small enough to explain in an interview, but realistic enough to show production engineering judgment. The library supports valuation and common risk measures across Rates, FX, Credit, and Mortgages using immutable requests, typed products, stateless pricers, market data snapshots, validation, audit traces, scenario revaluation, and regression comparison.

This is not a full pricing system. The formulas are intentionally illustrative. The design focus is the architecture: how a production-quality analytics library can remain testable, extensible, auditable, and independent from infrastructure.

## Design Goals

- Provide a clean Java 17 Maven project that compiles and passes tests.
- Keep the core library generic and clean-room.
- Support four asset classes: Rates, FX, Credit, and Mortgages.
- Support five measures: `PRESENT_VALUE`, `DV01`, `FX_DELTA`, `CS01`, and `OAS`.
- Keep pricers stateless.
- Route products through a `PricerRegistry`.
- Access market data only through `MarketDataSnapshot`.
- Validate request completeness before pricing.
- Attach calculation trace metadata to each result.
- Demonstrate scenario risk through bumped revaluation.
- Demonstrate release safety through regression comparison.

## Non-Goals

- No database dependency.
- No REST API.
- No queue or publisher implementation.
- No proprietary package names, schemas, or internal system terms.
- No complete financial model calibration.
- No distributed compute framework.

These choices keep the core valuation library focused. Infrastructure can be added later through adapters around the core API.

## Package Overview

```text
com.finrisk.analytics
  api          request/result facade contracts
  domain       shared trade, measure, valuation, and context models
  instrument   product definitions and lightweight asset-class product interfaces
  market       read-only market data snapshot boundary
  pricing      pricers, registry, and default financial library facade
  risk         scenario revaluation and regression comparison
  validation   reusable preconditions and request validation
  audit        calculation trace metadata
```

## Request Contract

`CalculationRequest` contains:

- `requestId`
- `valuationDate`
- `marketDataSetId`
- `modelVersion`
- `scenarioId`
- `tradeIds`
- `requestedMeasures`

The request includes trade ids but does not carry full trade payloads. That is intentional. In a real platform, trade sourcing may come from files, services, databases, or batch jobs. This library should not own those integration concerns. The caller loads full `Trade` objects and passes them to `FinancialLibrary.calculate(...)`.

`RequestValidator` checks that requested trade ids were loaded and that each product's market data requirements are available in the provided `MarketDataSnapshot`.

## Product Model

All products implement `Product`, which exposes:

- `productType()`
- `assetClass()`
- `marketDataRequirements()`

`Product` also contains lightweight nested asset-class interfaces:

- `Product.RatesProduct`
- `Product.FxProduct`
- `Product.CreditProduct`
- `Product.MortgageProduct`

These interfaces communicate product intent without creating a large inheritance tree. Concrete product records remain easy to read:

- `InterestRateSwap`
- `FxForward`
- `CreditDefaultSwap`
- `MortgagePool`

## Market Data Boundary

`MarketDataSnapshot` is the only market data interface used by pricers. This prevents product and pricing logic from depending on a database, cache, API, or vendor schema.

The demo implementation, `InMemoryMarketDataSnapshot`, supports:

- discount factors
- FX rates
- credit spreads
- OAS spreads
- prepayment assumptions

It exists for tests and demonstration. A production system could add market data loaders outside the core library and still pass the same snapshot interface to pricers.

## Pricing Architecture

The top-level entry point is `FinancialLibrary`.

`DefaultFinancialLibrary` performs orchestration:

1. Validate request, trades, and market data.
2. Build `PricingContext`.
3. Resolve each product through `PricerRegistry`.
4. Invoke the stateless `TradePricer`.
5. Normalize pricing results into `TradeValuation`.
6. Return a `CalculationResult`.

Each pricer implements `TradePricer`:

- `RatesSwapPricer`
- `FxForwardPricer`
- `CreditDefaultSwapPricer`
- `MortgagePoolPricer`

Each pricer is deliberately stateless, which makes the design easier to test, reason about, parallelize, and reuse.

## Measure Model

`RiskMeasure` is an enum for readability:

- `PRESENT_VALUE`
- `DV01`
- `FX_DELTA`
- `CS01`
- `OAS`

It implements `MeasureDefinition`, which provides:

- code
- display name
- description
- supported asset classes

This keeps the current design simple while leaving room for a production measure catalog or registry.

## Validation

Validation has two layers:

`Require` handles small reusable precondition checks:

- non-null required objects
- non-blank identifiers
- non-empty sets
- defensive list copies
- finite non-zero numbers

`RequestValidator` handles calculation-level validation:

- request exists
- trades exist
- market data exists
- requested trade ids were loaded
- product market data requirements are available

The library returns validation failures in `CalculationResult` instead of letting missing market data fail later inside pricing.

## Audit Trace

Every `TradeValuation` carries a `CalculationTrace` with:

- request id
- valuation date
- market data set id
- model version
- scenario id
- pricer name
- calculation timestamp

This supports reproducibility, audit review, model governance, and operational debugging.

## Scenario Risk

`ScenarioRiskCalculator` demonstrates bumped PV revaluation:

1. Calculate base PV.
2. Apply a simple market data bump.
3. Revalue with the bumped snapshot.
4. Return trade-level PV differences.

This is intentionally not a full scenario platform. It is a clean extension example showing that scenario risk can reuse the same pricing path instead of embedding scenario logic in each pricer.

## Regression Comparison

`ResultComparator` compares baseline and candidate `CalculationResult` objects with a numeric tolerance. This is useful for:

- release validation
- refactoring safety
- model upgrades
- regression test packs

Its nested `ComparisonResult` keeps the file structure lean while preserving a clear return contract.

## Testing Strategy

The JUnit test suite covers:

- pricing a multi-asset portfolio with four demo trades
- registry routing for each product
- requested risk measure coverage
- missing market data validation failure
- bumped scenario risk result
- regression comparison within and outside tolerance
- audit trace metadata

This test scope is intentionally focused on architecture behavior rather than formula precision.

## Extension Examples

To add a new product:

1. Create a product record implementing `Product` or an asset-class marker interface.
2. Declare its `productType`.
3. Declare its `marketDataRequirements`.
4. Implement a stateless `TradePricer`.
5. Register the pricer in `PricerRegistry`.
6. Add tests for routing, validation, and requested measures.

To add a new risk measure:

1. Add a standard `RiskMeasure` or introduce a richer `MeasureDefinition` registry.
2. Implement the measure in relevant pricers.
3. Add request/result coverage tests.
4. Add regression comparison examples if needed.

To add real integration:

1. Build trade loaders outside the core library.
2. Build market data loaders outside the core library.
3. Pass loaded `Trade` objects and `MarketDataSnapshot` into the facade.
4. Keep persistence and publishing outside the pricing path.

## Key Tradeoffs

The design uses Java records to reduce boilerplate and emphasize immutability. It keeps `RiskMeasure` as an enum for readability, but adds `MeasureDefinition` to show extensibility. It uses lightweight product marker interfaces rather than a deep product hierarchy. It keeps scenario risk simple because the assignment is about architecture, not full financial modeling.

The result is deliberately compact: enough structure to show senior engineering judgment, but not so much abstraction that the code becomes hard to explain.
