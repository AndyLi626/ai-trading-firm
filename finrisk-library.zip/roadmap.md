# Roadmap

## Phase 0: Review-Ready Skeleton

Goal: demonstrate clean architecture, extensibility, and production controls in a compact Java 17 Maven project.

Current state:

- 33 main Java files and 1 JUnit test file.
- Immutable request/result records.
- Rates, FX, credit, and mortgage product examples.
- Lightweight asset-class product interfaces.
- Stateless pricers behind a shared `TradePricer` contract.
- `PricerRegistry` routing.
- `MarketDataSnapshot` boundary.
- Reusable `Require` precondition helper.
- Request validation, market data validation, traceability, scenario risk, and regression comparison.
- JUnit tests for the required behaviors.

Exit criteria:

- `mvn test` passes.
- A reviewer can explain request -> validation -> market data -> pricer registry -> pricing result -> trace.
- The code has no database, REST, queue, or proprietary dependency.

## Phase 1: Analytics Depth

Add richer model implementations while preserving the public contracts:

- Curve interpolation and discounting conventions.
- Schedule generation and day-count handling.
- FX forwards with discount curves.
- Credit survival curves and recovery assumptions.
- Mortgage cashflow and prepayment model hooks.
- More precise measure definitions and reporting labels.

Exit criteria:

- Existing request/result contracts remain stable.
- New formulas are covered by focused model tests.
- Market data access still goes through `MarketDataSnapshot`.

## Phase 2: Model Governance

Add controls expected in production model environments:

- Model selection policy.
- Versioned model configuration.
- Explain payloads for valuation lineage.
- Structured validation diagnostics.
- Golden-copy regression packs.
- Formal baseline vs candidate tolerance reports.

Exit criteria:

- Results can be reproduced by request id, valuation date, market data set id, model version, scenario id, and pricer name.
- Model upgrades can be compared before release.

## Phase 3: Scenario And Risk Expansion

Grow scenario support while keeping pricers stateless:

- Scenario sets and named shocks.
- Curve, FX, spread, OAS, and prepayment shocks.
- Bucketed sensitivities.
- Portfolio-level aggregation.
- Risk result normalization.

Exit criteria:

- Scenario calculations reuse the same pricing path.
- New risk measures do not require orchestration rewrites.

## Phase 4: Performance

Improve runtime characteristics without changing pricer semantics:

- Portfolio partitioning.
- Market data snapshot reuse.
- Sensitivity batching.
- Benchmark profiles.
- Memory and latency limits.

Exit criteria:

- Batch behavior is predictable under larger portfolios.
- Pricers remain stateless and thread-safe.

## Phase 5: Integration Layer

Keep integration outside the core library:

- Batch adapters.
- Service facade if needed.
- Persistence adapters.
- Result publication adapters.
- Entitlement and operational controls.

Exit criteria:

- The core library remains usable in unit tests without infrastructure.
- Infrastructure concerns do not leak into product or pricer classes.
