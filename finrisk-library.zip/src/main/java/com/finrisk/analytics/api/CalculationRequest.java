package com.finrisk.analytics.api;

import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.validation.Require;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

public record CalculationRequest(
        String requestId,
        LocalDate valuationDate,
        String marketDataSetId,
        String modelVersion,
        String scenarioId,
        List<String> tradeIds,
        Set<RiskMeasure> requestedMeasures) {

    public CalculationRequest {
        requestId = Require.text(requestId, "requestId");
        valuationDate = Require.nonNull(valuationDate, "valuationDate");
        marketDataSetId = Require.text(marketDataSetId, "marketDataSetId");
        modelVersion = Require.text(modelVersion, "modelVersion");
        scenarioId = scenarioId == null || scenarioId.isBlank() ? "BASE" : scenarioId;
        tradeIds = Require.listCopyOrEmpty(tradeIds);
        requestedMeasures = Require.nonEmptySet(requestedMeasures, "requestedMeasures");
    }

    public CalculationRequest withScenario(String nextScenarioId, Set<RiskMeasure> measures) {
        return new CalculationRequest(
                requestId,
                valuationDate,
                marketDataSetId,
                modelVersion,
                nextScenarioId,
                tradeIds,
                measures);
    }
}

