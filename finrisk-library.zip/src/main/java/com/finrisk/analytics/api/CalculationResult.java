package com.finrisk.analytics.api;

import com.finrisk.analytics.domain.TradeValuation;
import com.finrisk.analytics.validation.Require;
import com.finrisk.analytics.validation.ValidationResult;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public record CalculationResult(
        CalculationRequest request,
        List<TradeValuation> valuations,
        ValidationResult validation,
        List<String> warnings) {

    public CalculationResult {
        request = Require.nonNull(request, "request");
        valuations = Require.listCopy(valuations, "valuations");
        validation = Require.nonNull(validation, "validation");
        warnings = Require.listCopy(warnings, "warnings");
    }

    public boolean successful() {
        return validation.isValid();
    }

    public Map<String, TradeValuation> valuationsByTradeId() {
        return valuations.stream()
                .collect(Collectors.toUnmodifiableMap(TradeValuation::tradeId, Function.identity()));
    }
}

