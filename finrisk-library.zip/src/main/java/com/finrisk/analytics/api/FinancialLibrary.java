package com.finrisk.analytics.api;

import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.market.MarketDataSnapshot;

import java.util.List;

public interface FinancialLibrary {

    CalculationResult calculate(
            CalculationRequest request,
            List<Trade> trades,
            MarketDataSnapshot marketDataSnapshot);
}

