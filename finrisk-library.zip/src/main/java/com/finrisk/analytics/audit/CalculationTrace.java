package com.finrisk.analytics.audit;

import com.finrisk.analytics.domain.PricingContext;
import com.finrisk.analytics.validation.Require;

import java.time.Instant;
import java.time.LocalDate;

public record CalculationTrace(
        String requestId,
        LocalDate valuationDate,
        String marketDataSetId,
        String modelVersion,
        String scenarioId,
        String pricerName,
        Instant calculatedAt) {

    public CalculationTrace {
        requestId = Require.text(requestId, "requestId");
        valuationDate = Require.nonNull(valuationDate, "valuationDate");
        marketDataSetId = Require.text(marketDataSetId, "marketDataSetId");
        modelVersion = Require.text(modelVersion, "modelVersion");
        scenarioId = scenarioId == null || scenarioId.isBlank() ? "BASE" : scenarioId;
        pricerName = Require.text(pricerName, "pricerName");
        calculatedAt = calculatedAt == null ? Instant.now() : calculatedAt;
    }

    public static CalculationTrace from(PricingContext context, String pricerName) {
        context = Require.nonNull(context, "context");
        return new CalculationTrace(
                context.requestId(),
                context.valuationDate(),
                context.marketDataSetId(),
                context.modelVersion(),
                context.scenarioId(),
                pricerName,
                Instant.now());
    }
}

