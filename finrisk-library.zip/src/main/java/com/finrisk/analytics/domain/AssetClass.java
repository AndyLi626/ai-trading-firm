package com.finrisk.analytics.domain;

public enum AssetClass {
    RATES,
    FX,
    CREDIT,
    MORTGAGES
}

