package com.finrisk.analytics.domain;

import java.util.Set;

public interface MeasureDefinition {

    String code();

    String displayName();

    String description();

    Set<AssetClass> supportedAssetClasses();
}
