package com.finrisk.analytics.domain;

import java.time.LocalDate;

public record PricingContext(
        String requestId,
        LocalDate valuationDate,
        String marketDataSetId,
        String modelVersion,
        String scenarioId) {
}

