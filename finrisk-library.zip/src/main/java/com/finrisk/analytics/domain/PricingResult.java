package com.finrisk.analytics.domain;

import com.finrisk.analytics.audit.CalculationTrace;
import com.finrisk.analytics.validation.Require;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public record PricingResult(
        Trade trade,
        Map<RiskMeasure, Double> measures,
        CalculationTrace trace,
        List<String> warnings) {

    public PricingResult {
        trade = Require.nonNull(trade, "trade");
        measures = Map.copyOf(new LinkedHashMap<>(Require.nonNull(measures, "measures")));
        trace = Require.nonNull(trace, "trace");
        warnings = Require.listCopy(warnings, "warnings");
    }
}

