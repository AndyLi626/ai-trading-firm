package com.finrisk.analytics.domain;

import java.util.EnumSet;
import java.util.Set;

public enum RiskMeasure implements MeasureDefinition {
    PRESENT_VALUE(
            "Present Value",
            "Illustrative mark-to-model value in reporting currency.",
            EnumSet.allOf(AssetClass.class)),
    DV01(
            "DV01",
            "Illustrative rates sensitivity from a one basis point market move.",
            EnumSet.of(AssetClass.RATES)),
    FX_DELTA(
            "FX Delta",
            "Illustrative spot FX sensitivity.",
            EnumSet.of(AssetClass.FX)),
    CS01(
            "CS01",
            "Illustrative credit spread sensitivity from a one basis point market move.",
            EnumSet.of(AssetClass.CREDIT)),
    OAS(
            "Option-Adjusted Spread",
            "Illustrative mortgage option-adjusted spread output.",
            EnumSet.of(AssetClass.MORTGAGES));

    private final String displayName;
    private final String description;
    private final Set<AssetClass> supportedAssetClasses;

    RiskMeasure(String displayName, String description, Set<AssetClass> supportedAssetClasses) {
        this.displayName = displayName;
        this.description = description;
        this.supportedAssetClasses = Set.copyOf(supportedAssetClasses);
    }

    @Override
    public String code() {
        return name();
    }

    @Override
    public String displayName() {
        return displayName;
    }

    @Override
    public String description() {
        return description;
    }

    @Override
    public Set<AssetClass> supportedAssetClasses() {
        return supportedAssetClasses;
    }
}
