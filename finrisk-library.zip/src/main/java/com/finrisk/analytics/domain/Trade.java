package com.finrisk.analytics.domain;

import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.validation.Require;

public record Trade(
        String tradeId,
        Product product,
        double quantity,
        String book) {

    public Trade {
        tradeId = Require.text(tradeId, "tradeId");
        product = Require.nonNull(product, "product");
        quantity = Require.finiteNonZero(quantity, "quantity");
        book = book == null || book.isBlank() ? "UNASSIGNED" : book;
    }
}

