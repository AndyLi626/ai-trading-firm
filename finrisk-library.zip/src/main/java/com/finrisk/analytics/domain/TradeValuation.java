package com.finrisk.analytics.domain;

import com.finrisk.analytics.audit.CalculationTrace;
import com.finrisk.analytics.validation.Require;

import java.util.LinkedHashMap;
import java.util.Map;

public record TradeValuation(
        String tradeId,
        String productType,
        AssetClass assetClass,
        Map<RiskMeasure, Double> measures,
        CalculationTrace trace) {

    public TradeValuation {
        tradeId = Require.text(tradeId, "tradeId");
        productType = Require.text(productType, "productType");
        assetClass = Require.nonNull(assetClass, "assetClass");
        measures = Map.copyOf(new LinkedHashMap<>(Require.nonNull(measures, "measures")));
        trace = Require.nonNull(trace, "trace");
    }

    public static TradeValuation from(PricingResult pricingResult) {
        var trade = pricingResult.trade();
        return new TradeValuation(
                trade.tradeId(),
                trade.product().productType(),
                trade.product().assetClass(),
                pricingResult.measures(),
                pricingResult.trace());
    }
}

