package com.finrisk.analytics.instrument;

import com.finrisk.analytics.market.CurveId;
import com.finrisk.analytics.market.MarketDataRequirement;

import java.util.Set;

public record CreditDefaultSwap(
        String referenceEntity,
        CurveId creditCurve,
        CurveId discountCurve,
        double coupon,
        double maturityYears) implements Product.CreditProduct {

    @Override
    public String productType() {
        return "CREDIT_DEFAULT_SWAP";
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(
                MarketDataRequirement.creditSpread(creditCurve, maturityYears),
                MarketDataRequirement.discountFactor(discountCurve, maturityYears));
    }
}

