package com.finrisk.analytics.instrument;

import com.finrisk.analytics.market.MarketDataRequirement;

import java.util.Set;

public record FxForward(
        String baseCurrency,
        String quoteCurrency,
        double agreedForwardRate,
        double maturityYears) implements Product.FxProduct {

    public String currencyPair() {
        return baseCurrency + "/" + quoteCurrency;
    }

    @Override
    public String productType() {
        return "FX_FORWARD";
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(MarketDataRequirement.fxRate(currencyPair()));
    }
}

