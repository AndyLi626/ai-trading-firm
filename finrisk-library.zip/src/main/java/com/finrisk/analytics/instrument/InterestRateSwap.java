package com.finrisk.analytics.instrument;

import com.finrisk.analytics.market.CurveId;
import com.finrisk.analytics.market.MarketDataRequirement;

import java.util.Set;

public record InterestRateSwap(
        String payCurrency,
        CurveId discountCurve,
        double fixedRate,
        double maturityYears) implements Product.RatesProduct {

    @Override
    public String productType() {
        return "INTEREST_RATE_SWAP";
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(MarketDataRequirement.discountFactor(discountCurve, maturityYears));
    }
}

