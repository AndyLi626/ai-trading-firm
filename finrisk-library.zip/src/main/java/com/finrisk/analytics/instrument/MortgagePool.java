package com.finrisk.analytics.instrument;

import com.finrisk.analytics.market.CurveId;
import com.finrisk.analytics.market.MarketDataRequirement;

import java.util.Set;

public record MortgagePool(
        String poolId,
        CurveId discountCurve,
        CurveId oasCurve,
        String prepaymentModel,
        double weightedAverageLifeYears) implements Product.MortgageProduct {

    @Override
    public String productType() {
        return "MORTGAGE_POOL";
    }

    @Override
    public Set<MarketDataRequirement> marketDataRequirements() {
        return Set.of(
                MarketDataRequirement.discountFactor(discountCurve, weightedAverageLifeYears),
                MarketDataRequirement.oasSpread(oasCurve, weightedAverageLifeYears),
                MarketDataRequirement.prepaymentRate(prepaymentModel, 12));
    }
}

