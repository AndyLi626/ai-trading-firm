package com.finrisk.analytics.instrument;

import com.finrisk.analytics.domain.AssetClass;
import com.finrisk.analytics.market.MarketDataRequirement;

import java.util.Set;

public interface Product {

    String productType();

    AssetClass assetClass();

    Set<MarketDataRequirement> marketDataRequirements();

    interface RatesProduct extends Product {
        @Override
        default AssetClass assetClass() {
            return AssetClass.RATES;
        }
    }

    interface FxProduct extends Product {
        @Override
        default AssetClass assetClass() {
            return AssetClass.FX;
        }
    }

    interface CreditProduct extends Product {
        @Override
        default AssetClass assetClass() {
            return AssetClass.CREDIT;
        }
    }

    interface MortgageProduct extends Product {
        @Override
        default AssetClass assetClass() {
            return AssetClass.MORTGAGES;
        }
    }
}

