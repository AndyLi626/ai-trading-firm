package com.finrisk.analytics.market;

import com.finrisk.analytics.validation.Require;

public record CurveId(String name) {

    public CurveId {
        name = Require.text(name, "curve name");
    }
}

