package com.finrisk.analytics.market;

import com.finrisk.analytics.validation.Require;

import java.util.HashMap;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.TreeMap;

public final class InMemoryMarketDataSnapshot implements MarketDataSnapshot {

    private final String marketDataSetId;
    private final Map<String, Map<Double, Double>> discountFactors;
    private final Map<String, Double> fxRates;
    private final Map<String, Map<Double, Double>> creditSpreads;
    private final Map<String, Map<Double, Double>> oasSpreads;
    private final Map<String, Map<Integer, Double>> prepaymentRates;

    private InMemoryMarketDataSnapshot(Builder builder) {
        this.marketDataSetId = builder.marketDataSetId;
        this.discountFactors = copyCurveMap(builder.discountFactors);
        this.fxRates = Map.copyOf(builder.fxRates);
        this.creditSpreads = copyCurveMap(builder.creditSpreads);
        this.oasSpreads = copyCurveMap(builder.oasSpreads);
        this.prepaymentRates = copyIntMap(builder.prepaymentRates);
    }

    public static Builder builder(String marketDataSetId) {
        return new Builder(marketDataSetId);
    }

    @Override
    public String marketDataSetId() {
        return marketDataSetId;
    }

    @Override
    public OptionalDouble discountFactor(CurveId curveId, double yearFraction) {
        return lookup(discountFactors, curveId.name(), yearFraction);
    }

    @Override
    public OptionalDouble fxRate(String currencyPair) {
        var value = fxRates.get(currencyPair);
        return value == null ? OptionalDouble.empty() : OptionalDouble.of(value);
    }

    @Override
    public OptionalDouble creditSpread(CurveId curveId, double yearFraction) {
        return lookup(creditSpreads, curveId.name(), yearFraction);
    }

    @Override
    public OptionalDouble oasSpread(CurveId curveId, double yearFraction) {
        return lookup(oasSpreads, curveId.name(), yearFraction);
    }

    @Override
    public OptionalDouble prepaymentRate(String modelKey, int month) {
        var monthlyRates = prepaymentRates.get(modelKey);
        if (monthlyRates == null || !monthlyRates.containsKey(month)) {
            return OptionalDouble.empty();
        }
        return OptionalDouble.of(monthlyRates.get(month));
    }

    @Override
    public boolean contains(MarketDataRequirement requirement) {
        return switch (requirement.type()) {
            case DISCOUNT_FACTOR -> containsCurvePoint(discountFactors, requirement.key());
            case FX_RATE -> fxRates.containsKey(requirement.key());
            case CREDIT_SPREAD -> containsCurvePoint(creditSpreads, requirement.key());
            case OAS_SPREAD -> containsCurvePoint(oasSpreads, requirement.key());
            case PREPAYMENT_RATE -> containsIntPoint(prepaymentRates, requirement.key());
        };
    }

    public InMemoryMarketDataSnapshot withBumpedDiscountFactors(CurveId curveId, double bump) {
        var builder = toBuilder();
        builder.bumpCurve(builder.discountFactors, curveId.name(), bump);
        return builder.build();
    }

    public InMemoryMarketDataSnapshot withBumpedCreditSpreads(CurveId curveId, double bump) {
        var builder = toBuilder();
        builder.bumpCurve(builder.creditSpreads, curveId.name(), bump);
        return builder.build();
    }

    public InMemoryMarketDataSnapshot withBumpedOasSpreads(CurveId curveId, double bump) {
        var builder = toBuilder();
        builder.bumpCurve(builder.oasSpreads, curveId.name(), bump);
        return builder.build();
    }

    public InMemoryMarketDataSnapshot withBumpedFxRate(String currencyPair, double bump) {
        var builder = toBuilder();
        builder.fxRates.computeIfPresent(currencyPair, (key, value) -> value + bump);
        return builder.build();
    }

    private Builder toBuilder() {
        var builder = builder(marketDataSetId);
        builder.discountFactors.putAll(copyCurveMap(discountFactors));
        builder.fxRates.putAll(fxRates);
        builder.creditSpreads.putAll(copyCurveMap(creditSpreads));
        builder.oasSpreads.putAll(copyCurveMap(oasSpreads));
        builder.prepaymentRates.putAll(copyIntMap(prepaymentRates));
        return builder;
    }

    private static OptionalDouble lookup(Map<String, Map<Double, Double>> values, String curveName, double yearFraction) {
        var curve = values.get(curveName);
        if (curve == null || !curve.containsKey(yearFraction)) {
            return OptionalDouble.empty();
        }
        return OptionalDouble.of(curve.get(yearFraction));
    }

    private static boolean containsCurvePoint(Map<String, Map<Double, Double>> values, String key) {
        var parts = key.split("@", 2);
        return parts.length == 2
                && values.containsKey(parts[0])
                && values.get(parts[0]).containsKey(Double.parseDouble(parts[1]));
    }

    private static boolean containsIntPoint(Map<String, Map<Integer, Double>> values, String key) {
        var parts = key.split("@", 2);
        return parts.length == 2
                && values.containsKey(parts[0])
                && values.get(parts[0]).containsKey(Integer.parseInt(parts[1]));
    }

    private static Map<String, Map<Double, Double>> copyCurveMap(Map<String, Map<Double, Double>> source) {
        var copy = new HashMap<String, Map<Double, Double>>();
        source.forEach((key, value) -> copy.put(key, Map.copyOf(value)));
        return Map.copyOf(copy);
    }

    private static Map<String, Map<Integer, Double>> copyIntMap(Map<String, Map<Integer, Double>> source) {
        var copy = new HashMap<String, Map<Integer, Double>>();
        source.forEach((key, value) -> copy.put(key, Map.copyOf(value)));
        return Map.copyOf(copy);
    }

    public static final class Builder {
        private final String marketDataSetId;
        private final Map<String, Map<Double, Double>> discountFactors = new HashMap<>();
        private final Map<String, Double> fxRates = new HashMap<>();
        private final Map<String, Map<Double, Double>> creditSpreads = new HashMap<>();
        private final Map<String, Map<Double, Double>> oasSpreads = new HashMap<>();
        private final Map<String, Map<Integer, Double>> prepaymentRates = new HashMap<>();

        private Builder(String marketDataSetId) {
            this.marketDataSetId = Require.text(marketDataSetId, "marketDataSetId");
        }

        public Builder discountFactor(CurveId curveId, double yearFraction, double value) {
            curve(discountFactors, curveId.name()).put(yearFraction, value);
            return this;
        }

        public Builder fxRate(String baseCurrency, String quoteCurrency, double value) {
            fxRates.put(baseCurrency + "/" + quoteCurrency, value);
            return this;
        }

        public Builder creditSpread(CurveId curveId, double yearFraction, double value) {
            curve(creditSpreads, curveId.name()).put(yearFraction, value);
            return this;
        }

        public Builder oasSpread(CurveId curveId, double yearFraction, double value) {
            curve(oasSpreads, curveId.name()).put(yearFraction, value);
            return this;
        }

        public Builder prepaymentRate(String modelKey, int month, double value) {
            prepaymentRates.computeIfAbsent(modelKey, ignored -> new TreeMap<>()).put(month, value);
            return this;
        }

        public InMemoryMarketDataSnapshot build() {
            return new InMemoryMarketDataSnapshot(this);
        }

        private void bumpCurve(Map<String, Map<Double, Double>> curves, String curveName, double bump) {
            curves.computeIfPresent(curveName, (key, value) -> {
                var bumped = new TreeMap<Double, Double>();
                value.forEach((tenor, point) -> bumped.put(tenor, point + bump));
                return bumped;
            });
        }

        private static Map<Double, Double> curve(Map<String, Map<Double, Double>> curves, String curveName) {
            return curves.computeIfAbsent(curveName, ignored -> new TreeMap<>());
        }
    }
}

