package com.finrisk.analytics.market;

import java.util.OptionalDouble;

public interface MarketDataSnapshot {

    String marketDataSetId();

    OptionalDouble discountFactor(CurveId curveId, double yearFraction);

    OptionalDouble fxRate(String currencyPair);

    OptionalDouble creditSpread(CurveId curveId, double yearFraction);

    OptionalDouble oasSpread(CurveId curveId, double yearFraction);

    OptionalDouble prepaymentRate(String modelKey, int month);

    boolean contains(MarketDataRequirement requirement);
}

