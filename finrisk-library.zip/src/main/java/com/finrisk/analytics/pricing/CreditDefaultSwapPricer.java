package com.finrisk.analytics.pricing;

import com.finrisk.analytics.audit.CalculationTrace;
import com.finrisk.analytics.domain.PricingContext;
import com.finrisk.analytics.domain.PricingResult;
import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.instrument.CreditDefaultSwap;
import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.market.MarketDataSnapshot;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public final class CreditDefaultSwapPricer implements TradePricer {

    @Override
    public String pricerName() {
        return "CreditDefaultSwapPricer";
    }

    @Override
    public boolean supports(Product product) {
        return product instanceof CreditDefaultSwap;
    }

    @Override
    public PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context) {
        var cds = (CreditDefaultSwap) trade.product();
        var discountFactor = marketDataSnapshot.discountFactor(cds.discountCurve(), cds.maturityYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing discount factor for " + cds.discountCurve()));
        var spread = marketDataSnapshot.creditSpread(cds.creditCurve(), cds.maturityYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing credit spread for " + cds.creditCurve()));
        var presentValue = trade.quantity() * (cds.coupon() - spread) * cds.maturityYears() * discountFactor;
        var measures = new LinkedHashMap<RiskMeasure, Double>();
        if (requestedMeasures.contains(RiskMeasure.PRESENT_VALUE)) {
            measures.put(RiskMeasure.PRESENT_VALUE, presentValue);
        }
        if (requestedMeasures.contains(RiskMeasure.CS01)) {
            measures.put(RiskMeasure.CS01, -trade.quantity() * cds.maturityYears() * discountFactor * 0.0001d);
        }
        return new PricingResult(trade, measures, CalculationTrace.from(context, pricerName()), List.of());
    }
}

