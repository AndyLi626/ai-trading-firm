package com.finrisk.analytics.pricing;

import com.finrisk.analytics.api.CalculationRequest;
import com.finrisk.analytics.api.CalculationResult;
import com.finrisk.analytics.api.FinancialLibrary;
import com.finrisk.analytics.domain.PricingContext;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.domain.TradeValuation;
import com.finrisk.analytics.market.MarketDataSnapshot;
import com.finrisk.analytics.validation.Require;
import com.finrisk.analytics.validation.RequestValidator;
import com.finrisk.analytics.validation.ValidationResult;

import java.util.ArrayList;
import java.util.List;

public final class DefaultFinancialLibrary implements FinancialLibrary {

    private final PricerRegistry pricerRegistry;
    private final RequestValidator requestValidator;

    public DefaultFinancialLibrary(PricerRegistry pricerRegistry, RequestValidator requestValidator) {
        this.pricerRegistry = Require.nonNull(pricerRegistry, "pricerRegistry");
        this.requestValidator = Require.nonNull(requestValidator, "requestValidator");
    }

    public static DefaultFinancialLibrary standard() {
        return new DefaultFinancialLibrary(PricerRegistry.standard(), new RequestValidator());
    }

    @Override
    public CalculationResult calculate(
            CalculationRequest request,
            List<Trade> trades,
            MarketDataSnapshot marketDataSnapshot) {
        var validation = requestValidator.validate(request, trades, marketDataSnapshot);
        if (!validation.isValid()) {
            return new CalculationResult(request, List.of(), validation, validation.errors());
        }

        var context = new PricingContext(
                request.requestId(),
                request.valuationDate(),
                marketDataSnapshot.marketDataSetId(),
                request.modelVersion(),
                request.scenarioId());

        var valuations = new ArrayList<TradeValuation>();
        var warnings = new ArrayList<String>();
        for (Trade trade : trades) {
            var pricer = pricerRegistry.resolve(trade.product());
            var pricingResult = pricer.price(trade, marketDataSnapshot, request.requestedMeasures(), context);
            valuations.add(TradeValuation.from(pricingResult));
            warnings.addAll(pricingResult.warnings());
        }

        return new CalculationResult(request, valuations, ValidationResult.valid(), warnings);
    }
}

