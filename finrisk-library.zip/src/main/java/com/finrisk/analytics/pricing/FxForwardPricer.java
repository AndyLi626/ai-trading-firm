package com.finrisk.analytics.pricing;

import com.finrisk.analytics.audit.CalculationTrace;
import com.finrisk.analytics.domain.PricingContext;
import com.finrisk.analytics.domain.PricingResult;
import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.instrument.FxForward;
import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.market.MarketDataSnapshot;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public final class FxForwardPricer implements TradePricer {

    @Override
    public String pricerName() {
        return "FxForwardPricer";
    }

    @Override
    public boolean supports(Product product) {
        return product instanceof FxForward;
    }

    @Override
    public PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context) {
        var forward = (FxForward) trade.product();
        var spot = marketDataSnapshot.fxRate(forward.currencyPair())
                .orElseThrow(() -> new IllegalArgumentException("Missing FX rate for " + forward.currencyPair()));
        var presentValue = trade.quantity() * (spot - forward.agreedForwardRate());
        var measures = new LinkedHashMap<RiskMeasure, Double>();
        if (requestedMeasures.contains(RiskMeasure.PRESENT_VALUE)) {
            measures.put(RiskMeasure.PRESENT_VALUE, presentValue);
        }
        if (requestedMeasures.contains(RiskMeasure.FX_DELTA)) {
            measures.put(RiskMeasure.FX_DELTA, trade.quantity());
        }
        return new PricingResult(trade, measures, CalculationTrace.from(context, pricerName()), List.of());
    }
}

