package com.finrisk.analytics.pricing;

import com.finrisk.analytics.audit.CalculationTrace;
import com.finrisk.analytics.domain.PricingContext;
import com.finrisk.analytics.domain.PricingResult;
import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.instrument.MortgagePool;
import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.market.MarketDataSnapshot;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public final class MortgagePoolPricer implements TradePricer {

    @Override
    public String pricerName() {
        return "MortgagePoolPricer";
    }

    @Override
    public boolean supports(Product product) {
        return product instanceof MortgagePool;
    }

    @Override
    public PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context) {
        var pool = (MortgagePool) trade.product();
        var discountFactor = marketDataSnapshot.discountFactor(pool.discountCurve(), pool.weightedAverageLifeYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing discount factor for " + pool.discountCurve()));
        var oas = marketDataSnapshot.oasSpread(pool.oasCurve(), pool.weightedAverageLifeYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing OAS spread for " + pool.oasCurve()));
        var prepay = marketDataSnapshot.prepaymentRate(pool.prepaymentModel(), 12)
                .orElseThrow(() -> new IllegalArgumentException("Missing prepayment rate for " + pool.prepaymentModel()));
        var presentValue = trade.quantity() * discountFactor * (1.0d - oas * pool.weightedAverageLifeYears()) * (1.0d - prepay * 0.50d);
        var measures = new LinkedHashMap<RiskMeasure, Double>();
        if (requestedMeasures.contains(RiskMeasure.PRESENT_VALUE)) {
            measures.put(RiskMeasure.PRESENT_VALUE, presentValue);
        }
        if (requestedMeasures.contains(RiskMeasure.OAS)) {
            measures.put(RiskMeasure.OAS, oas * 10_000.0d);
        }
        return new PricingResult(trade, measures, CalculationTrace.from(context, pricerName()), List.of());
    }
}

