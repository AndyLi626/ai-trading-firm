package com.finrisk.analytics.pricing;

import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.validation.Require;

import java.util.List;

public final class PricerRegistry {

    private final List<TradePricer> pricers;

    public PricerRegistry(List<TradePricer> pricers) {
        if (pricers == null || pricers.isEmpty()) {
            throw new IllegalArgumentException("at least one pricer must be registered");
        }
        this.pricers = List.copyOf(pricers);
    }

    public static PricerRegistry standard() {
        return new PricerRegistry(List.of(
                new RatesSwapPricer(),
                new FxForwardPricer(),
                new CreditDefaultSwapPricer(),
                new MortgagePoolPricer()));
    }

    public TradePricer resolve(Product product) {
        var validatedProduct = Require.nonNull(product, "product");
        return pricers.stream()
                .filter(pricer -> pricer.supports(validatedProduct))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "No pricer registered for " + validatedProduct.productType()));
    }

    public List<TradePricer> registeredPricers() {
        return pricers;
    }
}

