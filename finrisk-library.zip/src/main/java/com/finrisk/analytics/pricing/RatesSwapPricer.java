package com.finrisk.analytics.pricing;

import com.finrisk.analytics.audit.CalculationTrace;
import com.finrisk.analytics.domain.PricingContext;
import com.finrisk.analytics.domain.PricingResult;
import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.instrument.InterestRateSwap;
import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.market.MarketDataSnapshot;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

public final class RatesSwapPricer implements TradePricer {

    @Override
    public String pricerName() {
        return "RatesSwapPricer";
    }

    @Override
    public boolean supports(Product product) {
        return product instanceof InterestRateSwap;
    }

    @Override
    public PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context) {
        var swap = (InterestRateSwap) trade.product();
        var discountFactor = marketDataSnapshot.discountFactor(swap.discountCurve(), swap.maturityYears())
                .orElseThrow(() -> new IllegalArgumentException("Missing discount factor for " + swap.discountCurve()));
        var parRate = Math.pow(1.0d / discountFactor, 1.0d / swap.maturityYears()) - 1.0d;
        var presentValue = trade.quantity() * (swap.fixedRate() - parRate) * swap.maturityYears() * discountFactor;
        var measures = new LinkedHashMap<RiskMeasure, Double>();
        if (requestedMeasures.contains(RiskMeasure.PRESENT_VALUE)) {
            measures.put(RiskMeasure.PRESENT_VALUE, presentValue);
        }
        if (requestedMeasures.contains(RiskMeasure.DV01)) {
            measures.put(RiskMeasure.DV01, trade.quantity() * swap.maturityYears() * discountFactor * 0.0001d);
        }
        return new PricingResult(trade, measures, CalculationTrace.from(context, pricerName()), List.of());
    }
}

