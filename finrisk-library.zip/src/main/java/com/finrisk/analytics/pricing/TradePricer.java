package com.finrisk.analytics.pricing;

import com.finrisk.analytics.domain.PricingContext;
import com.finrisk.analytics.domain.PricingResult;
import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.market.MarketDataSnapshot;

import java.util.Set;

public interface TradePricer {

    String pricerName();

    boolean supports(Product product);

    PricingResult price(
            Trade trade,
            MarketDataSnapshot marketDataSnapshot,
            Set<RiskMeasure> requestedMeasures,
            PricingContext context);
}

