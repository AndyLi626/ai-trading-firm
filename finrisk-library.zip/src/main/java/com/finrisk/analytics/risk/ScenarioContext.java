package com.finrisk.analytics.risk;

import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.market.CurveId;
import com.finrisk.analytics.market.MarketDataRequirement;
import com.finrisk.analytics.validation.Require;

public record ScenarioContext(
        String scenarioId,
        RiskMeasure riskMeasure,
        MarketDataRequirement.Type bumpType,
        CurveId curveId,
        String fxPair,
        double bumpSize) {

    public ScenarioContext {
        scenarioId = Require.text(scenarioId, "scenarioId");
        riskMeasure = Require.nonNull(riskMeasure, "riskMeasure");
        bumpType = Require.nonNull(bumpType, "bumpType");
        bumpSize = Require.finiteNonZero(bumpSize, "bumpSize");
    }
}

