package com.finrisk.analytics.risk;

import com.finrisk.analytics.api.CalculationRequest;
import com.finrisk.analytics.api.FinancialLibrary;
import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.market.InMemoryMarketDataSnapshot;
import com.finrisk.analytics.validation.Require;

import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ScenarioRiskCalculator {

    private final FinancialLibrary financialLibrary;

    public ScenarioRiskCalculator(FinancialLibrary financialLibrary) {
        this.financialLibrary = Require.nonNull(financialLibrary, "financialLibrary");
    }

    public ScenarioRiskResult calculateBumpedRisk(
            CalculationRequest request,
            List<Trade> trades,
            InMemoryMarketDataSnapshot marketDataSnapshot,
            ScenarioContext scenarioContext) {
        var pvOnlyRequest = request.withScenario("BASE", EnumSet.of(RiskMeasure.PRESENT_VALUE));
        var base = financialLibrary.calculate(pvOnlyRequest, trades, marketDataSnapshot);

        var bumpedMarketData = switch (scenarioContext.bumpType()) {
            case DISCOUNT_FACTOR -> marketDataSnapshot.withBumpedDiscountFactors(
                    scenarioContext.curveId(),
                    scenarioContext.bumpSize());
            case CREDIT_SPREAD -> marketDataSnapshot.withBumpedCreditSpreads(
                    scenarioContext.curveId(),
                    scenarioContext.bumpSize());
            case OAS_SPREAD -> marketDataSnapshot.withBumpedOasSpreads(
                    scenarioContext.curveId(),
                    scenarioContext.bumpSize());
            case FX_RATE -> marketDataSnapshot.withBumpedFxRate(
                    scenarioContext.fxPair(),
                    scenarioContext.bumpSize());
            case PREPAYMENT_RATE -> throw new IllegalArgumentException("Prepayment bumps are intentionally out of scope");
        };

        var bumpedRequest = request.withScenario(
                scenarioContext.scenarioId(),
                EnumSet.of(RiskMeasure.PRESENT_VALUE));
        var bumped = financialLibrary.calculate(bumpedRequest, trades, bumpedMarketData);

        var riskByTrade = new LinkedHashMap<String, Double>();
        for (var baseValuation : base.valuations()) {
            var candidate = bumped.valuationsByTradeId().get(baseValuation.tradeId());
            if (candidate != null) {
                var basePv = baseValuation.measures().getOrDefault(RiskMeasure.PRESENT_VALUE, 0.0d);
                var bumpedPv = candidate.measures().getOrDefault(RiskMeasure.PRESENT_VALUE, 0.0d);
                riskByTrade.put(baseValuation.tradeId(), bumpedPv - basePv);
            }
        }
        return new ScenarioRiskResult(
                scenarioContext.scenarioId(),
                scenarioContext.riskMeasure(),
                riskByTrade);
    }

    public record ScenarioRiskResult(
            String scenarioId,
            RiskMeasure riskMeasure,
            Map<String, Double> tradeRisk) {

        public ScenarioRiskResult {
            tradeRisk = Map.copyOf(tradeRisk);
        }
    }
}

