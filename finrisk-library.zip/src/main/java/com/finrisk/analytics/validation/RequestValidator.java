package com.finrisk.analytics.validation;

import com.finrisk.analytics.api.CalculationRequest;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.market.MarketDataSnapshot;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public final class RequestValidator {

    public ValidationResult validate(
            CalculationRequest request,
            List<Trade> trades,
            MarketDataSnapshot marketDataSnapshot) {
        var errors = new ArrayList<String>();
        if (request == null) {
            errors.add("Calculation request is required");
        }
        if (trades == null || trades.isEmpty()) {
            errors.add("At least one trade is required");
        }
        if (marketDataSnapshot == null) {
            errors.add("Market data snapshot is required");
        }
        if (!errors.isEmpty()) {
            return ValidationResult.invalid(errors);
        }

        if (!request.tradeIds().isEmpty()) {
            var requestedTradeIds = new HashSet<>(request.tradeIds());
            for (Trade trade : trades) {
                requestedTradeIds.remove(trade.tradeId());
            }
            if (!requestedTradeIds.isEmpty()) {
                errors.add("Request references trades that were not loaded: " + requestedTradeIds);
            }
        }

        for (Trade trade : trades) {
            for (var requirement : trade.product().marketDataRequirements()) {
                if (!marketDataSnapshot.contains(requirement)) {
                    errors.add("Missing market data for trade "
                            + trade.tradeId()
                            + ": "
                            + requirement.type()
                            + " "
                            + requirement.key());
                }
            }
        }
        return errors.isEmpty() ? ValidationResult.valid() : ValidationResult.invalid(errors);
    }
}

