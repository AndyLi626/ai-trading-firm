package com.finrisk.analytics.validation;

import java.util.List;
import java.util.Objects;
import java.util.Set;

public final class Require {

    private Require() {
    }

    public static <T> T nonNull(T value, String fieldName) {
        return Objects.requireNonNull(value, fieldName);
    }

    public static String text(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " must not be blank");
        }
        return value;
    }

    public static <T> List<T> listCopy(List<T> values, String fieldName) {
        return List.copyOf(nonNull(values, fieldName));
    }

    public static <T> List<T> listCopyOrEmpty(List<T> values) {
        return values == null ? List.of() : List.copyOf(values);
    }

    public static <T> Set<T> nonEmptySet(Set<T> values, String fieldName) {
        if (values == null || values.isEmpty()) {
            throw new IllegalArgumentException(fieldName + " must not be empty");
        }
        return Set.copyOf(values);
    }

    public static double finiteNonZero(double value, String fieldName) {
        if (!Double.isFinite(value) || value == 0.0d) {
            throw new IllegalArgumentException(fieldName + " must be finite and non-zero");
        }
        return value;
    }
}
