package com.finrisk.analytics;

import com.finrisk.analytics.api.CalculationRequest;
import com.finrisk.analytics.api.CalculationResult;
import com.finrisk.analytics.domain.AssetClass;
import com.finrisk.analytics.domain.RiskMeasure;
import com.finrisk.analytics.domain.Trade;
import com.finrisk.analytics.domain.TradeValuation;
import com.finrisk.analytics.instrument.CreditDefaultSwap;
import com.finrisk.analytics.instrument.FxForward;
import com.finrisk.analytics.instrument.InterestRateSwap;
import com.finrisk.analytics.instrument.MortgagePool;
import com.finrisk.analytics.instrument.Product;
import com.finrisk.analytics.market.CurveId;
import com.finrisk.analytics.market.InMemoryMarketDataSnapshot;
import com.finrisk.analytics.market.MarketDataRequirement;
import com.finrisk.analytics.pricing.CreditDefaultSwapPricer;
import com.finrisk.analytics.pricing.FxForwardPricer;
import com.finrisk.analytics.pricing.MortgagePoolPricer;
import com.finrisk.analytics.pricing.PricerRegistry;
import com.finrisk.analytics.pricing.RatesSwapPricer;
import com.finrisk.analytics.pricing.DefaultFinancialLibrary;
import com.finrisk.analytics.risk.ResultComparator;
import com.finrisk.analytics.risk.ScenarioContext;
import com.finrisk.analytics.risk.ScenarioRiskCalculator;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FinancialLibraryTest {

    private static final CurveId USD_CURVE = new CurveId("USD-SOFR");
    private static final CurveId CREDIT_CURVE = new CurveId("ACME-CDS");
    private static final CurveId MORTGAGE_OAS_CURVE = new CurveId("AGENCY-MBS-OAS");

    @Test
    void pricesMultiAssetPortfolioWithFourDemoTrades() {
        var result = library().calculate(request(), demoTrades(), marketData());

        assertTrue(result.successful());
        assertEquals(4, result.valuations().size());
    }

    @Test
    void pricerRegistryRoutesProductsToCorrectPricers() {
        var registry = PricerRegistry.standard();
        var trades = demoTrades();

        assertInstanceOf(Product.RatesProduct.class, trades.get(0).product());
        assertInstanceOf(Product.FxProduct.class, trades.get(1).product());
        assertInstanceOf(Product.CreditProduct.class, trades.get(2).product());
        assertInstanceOf(Product.MortgageProduct.class, trades.get(3).product());
        assertInstanceOf(RatesSwapPricer.class, registry.resolve(trades.get(0).product()));
        assertInstanceOf(FxForwardPricer.class, registry.resolve(trades.get(1).product()));
        assertInstanceOf(CreditDefaultSwapPricer.class, registry.resolve(trades.get(2).product()));
        assertInstanceOf(MortgagePoolPricer.class, registry.resolve(trades.get(3).product()));
    }

    @Test
    void requestedRiskMeasuresAreReturnedAcrossPortfolio() {
        var result = library().calculate(request(), demoTrades(), marketData());
        var returned = EnumSet.noneOf(RiskMeasure.class);
        result.valuations().forEach(valuation -> returned.addAll(valuation.measures().keySet()));

        assertEquals("DV01", RiskMeasure.DV01.code());
        assertTrue(RiskMeasure.DV01.supportedAssetClasses().contains(AssetClass.RATES));
        assertEquals(request().requestedMeasures(), returned);
    }

    @Test
    void missingMarketDataProducesValidationFailure() {
        var incompleteMarketData = InMemoryMarketDataSnapshot.builder("NY_CLOSE_20260425")
                .discountFactor(USD_CURVE, 5.0d, 0.91d)
                .fxRate("EUR", "USD", 1.08d)
                .discountFactor(USD_CURVE, 3.0d, 0.95d)
                .discountFactor(USD_CURVE, 4.0d, 0.93d)
                .oasSpread(MORTGAGE_OAS_CURVE, 4.0d, 0.0080d)
                .prepaymentRate("BASE_PREPAY", 12, 0.075d)
                .build();

        var result = library().calculate(request(), demoTrades(), incompleteMarketData);

        assertFalse(result.successful());
        assertTrue(result.validation().errors().stream().anyMatch(error -> error.contains("CREDIT_SPREAD")));
    }

    @Test
    void scenarioRiskCalculatorCalculatesBumpedDv01StyleResult() {
        var calculator = new ScenarioRiskCalculator(library());
        var scenario = new ScenarioContext(
                "USD_DF_UP_1BP",
                RiskMeasure.DV01,
                MarketDataRequirement.Type.DISCOUNT_FACTOR,
                USD_CURVE,
                null,
                0.0001d);

        var riskResult = calculator.calculateBumpedRisk(request(), demoTrades(), marketData(), scenario);

        assertEquals("USD_DF_UP_1BP", riskResult.scenarioId());
        assertTrue(Math.abs(riskResult.tradeRisk().get("SWAP-1001")) > 0.0d);
    }

    @Test
    void resultComparatorSeparatesWithinAndOutsideToleranceDifferences() {
        var baseline = library().calculate(request(), demoTrades(), marketData());
        var insideTolerance = new ResultComparator().compare(baseline, baseline, 0.01d);
        var outsideTolerance = new ResultComparator().compare(
                baseline,
                withFirstPvShifted(baseline, 10.0d),
                0.01d);

        assertTrue(insideTolerance.withinTolerance());
        assertFalse(outsideTolerance.withinTolerance());
    }

    @Test
    void calculationTraceContainsAuditFieldsAndPricerName() {
        var result = library().calculate(request(), demoTrades(), marketData());

        for (var valuation : result.valuations()) {
            var trace = valuation.trace();
            assertEquals("REQ-20260425-001", trace.requestId());
            assertEquals(LocalDate.of(2026, 4, 25), trace.valuationDate());
            assertEquals("NY_CLOSE_20260425", trace.marketDataSetId());
            assertEquals("demo-model-1", trace.modelVersion());
            assertEquals("BASE", trace.scenarioId());
            assertNotNull(trace.pricerName());
            assertFalse(trace.pricerName().isBlank());
        }
    }

    private static DefaultFinancialLibrary library() {
        return DefaultFinancialLibrary.standard();
    }

    private static CalculationRequest request() {
        return new CalculationRequest(
                "REQ-20260425-001",
                LocalDate.of(2026, 4, 25),
                "NY_CLOSE_20260425",
                "demo-model-1",
                "BASE",
                List.of("SWAP-1001", "FXFWD-2001", "CDS-3001", "MBS-4001"),
                Set.of(
                        RiskMeasure.PRESENT_VALUE,
                        RiskMeasure.DV01,
                        RiskMeasure.FX_DELTA,
                        RiskMeasure.CS01,
                        RiskMeasure.OAS));
    }

    private static List<Trade> demoTrades() {
        return List.of(
                new Trade(
                        "SWAP-1001",
                        new InterestRateSwap("USD", USD_CURVE, 0.0325d, 5.0d),
                        1_000_000.0d,
                        "RATES"),
                new Trade(
                        "FXFWD-2001",
                        new FxForward("EUR", "USD", 1.07d, 1.0d),
                        2_000_000.0d,
                        "FX"),
                new Trade(
                        "CDS-3001",
                        new CreditDefaultSwap("ACME", CREDIT_CURVE, USD_CURVE, 0.0150d, 3.0d),
                        3_000_000.0d,
                        "CREDIT"),
                new Trade(
                        "MBS-4001",
                        new MortgagePool("POOL-1", USD_CURVE, MORTGAGE_OAS_CURVE, "BASE_PREPAY", 4.0d),
                        4_000_000.0d,
                        "MORTGAGES"));
    }

    private static InMemoryMarketDataSnapshot marketData() {
        return InMemoryMarketDataSnapshot.builder("NY_CLOSE_20260425")
                .discountFactor(USD_CURVE, 5.0d, 0.91d)
                .discountFactor(USD_CURVE, 3.0d, 0.95d)
                .discountFactor(USD_CURVE, 4.0d, 0.93d)
                .fxRate("EUR", "USD", 1.08d)
                .creditSpread(CREDIT_CURVE, 3.0d, 0.0120d)
                .oasSpread(MORTGAGE_OAS_CURVE, 4.0d, 0.0080d)
                .prepaymentRate("BASE_PREPAY", 12, 0.075d)
                .build();
    }

    private static CalculationResult withFirstPvShifted(CalculationResult baseline, double shift) {
        var updated = baseline.valuations().stream()
                .map(valuation -> valuation.tradeId().equals("SWAP-1001") ? shiftPv(valuation, shift) : valuation)
                .toList();
        return new CalculationResult(baseline.request(), updated, baseline.validation(), baseline.warnings());
    }

    private static TradeValuation shiftPv(TradeValuation valuation, double shift) {
        var measures = new LinkedHashMap<>(valuation.measures());
        measures.computeIfPresent(RiskMeasure.PRESENT_VALUE, (key, value) -> value + shift);
        return new TradeValuation(
                valuation.tradeId(),
                valuation.productType(),
                valuation.assetClass(),
                measures,
                valuation.trace());
    }
}

