# Interview Questions

This file lists likely questions for a Lead Java Securities Quantitative Analytics Specialist interview and concise points to use in answers.

## Architecture And Design

1. **Can you walk me through the end-to-end flow?**
   Start with `CalculationRequest`, caller-loaded trades, `MarketDataSnapshot`, `RequestValidator`, `DefaultFinancialLibrary`, `PricerRegistry`, stateless pricer, `TradeValuation`, and `CalculationTrace`.

2. **Why did you separate request from trade loading?**
   The request is an execution contract. Trade sourcing is infrastructure-specific and should sit outside the core analytics library.

3. **Why is there no database dependency?**
   The assignment asks for a financial analytics library, not a platform service. Keeping persistence outside makes pricing testable and reusable.

4. **Why no REST API?**
   REST is an integration concern. The same core library could later be used by batch, REST, gRPC, or simulation workflows.

5. **Why use records?**
   Records make immutable request/result models concise and reduce boilerplate.

6. **Why use a pricer registry?**
   It centralizes routing and avoids large `if/else` blocks in the facade.

7. **Why are pricers stateless?**
   Stateless pricers are easier to test, parallelize, reason about, and reuse.

8. **Why is market data only accessed through `MarketDataSnapshot`?**
   It isolates pricing from data sources, vendor schemas, databases, and caches.

9. **Why include lightweight product interfaces?**
   They communicate asset-class intent without adding a large inheritance hierarchy.

10. **Why not create separate interfaces for every product type?**
    That would be too much ceremony for a skeleton. Concrete products plus asset-class markers are easier to explain.

11. **Why is `RiskMeasure` still an enum?**
    It keeps the standard measure set readable. `MeasureDefinition` adds metadata and leaves room for a future measure registry.

12. **What would you change for a production implementation?**
    Add real model implementations, market data loaders, curve construction, product lifecycle handling, scenario sets, governance, and performance profiling.

13. **How does the design support extension?**
    Add a product record, declare market data requirements, implement a stateless pricer, register it, and add tests.

14. **How does the design avoid over-engineering?**
    It uses clear interfaces where they protect boundaries and avoids infrastructure, deep hierarchies, and complex factories.

15. **What is the most important design boundary?**
    The boundary between core pricing and infrastructure: market data loading, trade sourcing, persistence, and APIs stay outside.

## Java And Code Quality

16. **Why Java 17?**
    Java 17 is a long-term support release and supports records, modern switch expressions, and cleaner immutable data modeling.

17. **Why Maven?**
    Maven is common in enterprise Java environments, easy for reviewers to run, and enough for this small library.

18. **What does `Require` do?**
    It centralizes reusable precondition checks for nulls, blank strings, collections, and finite numeric values.

19. **Why not use Bean Validation?**
    A dependency-free helper is enough for this assignment and keeps the core library small.

20. **How do you keep objects immutable?**
    Use records, defensive copies, `List.copyOf`, `Set.copyOf`, and `Map.copyOf`.

21. **Are the pricers thread-safe?**
    Yes, they are stateless. Thread safety then mainly depends on immutable inputs and read-only market data snapshots.

22. **What compile/test command should reviewers run?**
    `mvn test`.

23. **What tests are included?**
    Multi-asset pricing, pricer routing, requested measures, missing market data, scenario risk, comparator tolerance, and trace metadata.

24. **How would you improve test coverage next?**
    Add product-specific formula tests, edge cases, tolerance boundaries, and golden-copy regression scenarios.

25. **Why use nested records for comparison and scenario results?**
    They are small return contracts owned by a single class, so nesting keeps the source tree lean.

## Quant And Product Coverage

26. **Which asset classes are supported?**
    Rates, FX, Credit, and Mortgages.

27. **Which sample products are included?**
    Interest rate swap, FX forward, credit default swap, and mortgage pool.

28. **Which measures are supported?**
    Present value, DV01, FX delta, CS01, and OAS.

29. **Are the pricing formulas production-grade?**
    No. They are illustrative. The assignment focus is architecture and extensibility, not full model calibration.

30. **How would you implement real rates valuation?**
    Add schedules, calendars, day-count conventions, discount curves, projection curves, and cashflow discounting.

31. **How would you implement real FX forward valuation?**
    Use spot, domestic and foreign discount curves, forward points, settlement dates, and currency conventions.

32. **How would you implement real CDS valuation?**
    Use survival curves, recovery assumptions, premium/protection legs, accrual, and standard CDS conventions.

33. **How would you implement real mortgage analytics?**
    Add cashflow projection, prepayment models, OAS model assumptions, option-adjusted paths, and seasoning data.

34. **How should DV01 be calculated in production?**
    Usually through curve bump/revalue, analytic sensitivities, or algorithmic differentiation depending on model and performance requirements.

35. **How should CS01 be calculated in production?**
    Through spread curve bump/revalue or analytic credit spread sensitivities, with bucketed and parallel shocks.

36. **What is OAS?**
    Option-adjusted spread is the spread that equates modeled mortgage or callable bond value to market price after accounting for embedded optionality.

37. **How do you handle cross-asset portfolios?**
    Use a common request/result model and route each trade to an asset-specific pricer through the registry.

38. **How would you add key-rate DV01?**
    Add a measure definition, represent curve bucket requirements, bump individual tenors, revalue, and return bucketed results.

## Validation, Audit, And Controls

39. **What does validation catch?**
    Missing request, missing trades, missing market data snapshot, unloaded requested trades, and product market data gaps.

40. **Why validate before pricing?**
    It gives deterministic, clear failures instead of partial results or late pricer exceptions.

41. **What audit fields are captured?**
    Request id, valuation date, market data set id, model version, scenario id, pricer name, and timestamp.

42. **How does this support model governance?**
    Results carry enough lineage to reproduce or explain which request, data set, model version, scenario, and pricer produced them.

43. **How would you add structured diagnostics?**
    Replace string errors with typed diagnostic records containing code, severity, trade id, field, and message.

44. **How does regression comparison help?**
    It compares baseline and candidate results with tolerance, which is useful for release checks and model upgrades.

45. **What are the limitations of the current comparator?**
    It is trade/measure-level and numeric. Production might need portfolio aggregates, explain deltas, and severity thresholds.

## Scenario Risk

46. **How does scenario risk work in this project?**
    It calculates base PV, bumps market data, revalues, and returns trade-level PV differences.

47. **Is this full scenario infrastructure?**
    No. It is a focused extensibility example.

48. **Why use revaluation rather than embedding risk logic in each pricer?**
    Revaluation reuses the pricing path and keeps pricers simpler.

49. **How would you expand scenario risk?**
    Add scenario sets, shock definitions, aggregation, bucketed sensitivities, and result normalization.

50. **What scenario types would matter in production?**
    Rate curve shocks, FX shocks, credit spread shocks, OAS shocks, prepayment shocks, volatility shocks, and historical stress scenarios.

## Performance And Scalability

51. **How would this scale to large portfolios?**
    Partition trades, reuse immutable market snapshots, parallelize stateless pricers, and stream results if needed.

52. **Where would caching belong?**
    Outside or around market data/model construction, not inside stateless pricers unless carefully controlled.

53. **How do you avoid shared mutable state?**
    Use immutable request/result records, stateless pricers, and read-only market snapshots.

54. **What would you benchmark?**
    Per-trade pricing latency, portfolio throughput, memory use, scenario revaluation cost, and market data lookup hot spots.

55. **How would you handle partial failures?**
    Decide by workflow: fail-fast for strict runs, or return trade-level diagnostics for large batch runs.

## Leadership And Tradeoffs

56. **What tradeoff did you consciously make?**
    I chose a compact skeleton over a full pricing platform so reviewers can understand the architecture quickly.

57. **How would you explain this to a non-technical manager?**
    It separates analytics from infrastructure so models can be tested, audited, and reused safely.

58. **What is the strongest part of the design?**
    The clean boundary between request orchestration, market data access, pricer routing, and stateless valuation.

59. **What is the weakest part of the current implementation?**
    The formulas are intentionally simple and the scenario engine is only a revaluation example.

60. **How would you lead a team building this out?**
    Stabilize contracts first, add product/model depth incrementally, enforce tests and regression packs, and keep integration adapters outside the core.

61. **How would you handle disagreements about abstraction level?**
    Use actual extension needs and testability as the guide. Add abstraction only when it removes duplication or protects a boundary.

62. **How does this design reflect senior engineering judgment?**
    It is small, auditable, testable, and extensible without pretending to solve every production concern in one skeleton.

63. **What should the interviewer notice in the code?**
    Immutable records, stateless pricers, market data boundary, registry routing, validation before pricing, trace metadata, and focused tests.

64. **What would you say if asked why the package is `com.finrisk.analytics`?**
    It is generic and professional without referencing any company or proprietary internal naming.

65. **How would you summarize the project in one minute?**
    This is a clean Java 17 financial analytics library skeleton for multi-asset valuation and risk. It takes an immutable request, validates loaded trades and market data, routes each product through a stateless pricer, returns normalized trade valuations with audit trace, and includes scenario revaluation plus regression comparison controls.
