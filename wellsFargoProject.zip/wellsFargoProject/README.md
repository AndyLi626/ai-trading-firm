# FinRisk Library

FinRisk Library is a clean-room Java 17 Maven project that demonstrates the architecture of a production-minded financial analytics library. It supports valuation and common risk measures for four asset classes:

- Rates
- FX
- Credit
- Mortgages

The implementation is intentionally small. Pricing formulas and risk outputs are illustrative only; the goal is to show clear contracts, routing, validation, traceability, scenario revaluation, and regression comparison without over-engineering the assignment.

## Build And Test

```bash
mvn test
```

Current verification:

```text
Tests run: 7, Failures: 0, Errors: 0, Skipped: 0
```

## Review Documents

- [PROJECT_DESIGN.md](PROJECT_DESIGN.md): full design narrative and talking points.
- [INTERVIEW_QUESTIONS.md](INTERVIEW_QUESTIONS.md): likely interviewer questions with concise answer guidance.
- [architecture.yml](architecture.yml): structured architecture summary.
- [roadmap.md](roadmap.md): future production evolution plan.
- [sample-calculation-request.json](sample-calculation-request.json): sample request contract.

## Package

The Java package root is:

```text
com.finrisk.analytics
```

The project contains 33 main Java files and 1 JUnit test file. The main package responsibilities are:

- `api`: immutable request/result facade contracts.
- `domain`: common trade, valuation, measure, and pricing context models.
- `instrument`: product definitions plus lightweight asset-class product interfaces.
- `market`: read-only market data snapshot and in-memory demo implementation.
- `pricing`: stateless pricers, pricer registry, and default library facade.
- `risk`: scenario revaluation and regression comparison utilities.
- `validation`: reusable precondition helpers plus request and market data completeness checks.
- `audit`: calculation trace metadata.

## Core Abstractions

`CalculationRequest` is an immutable Java record containing request id, valuation date, market data set id, model version, scenario id, trade ids, and requested measures.

`Trade` wraps a product, quantity, and book. Products implement `Product` and declare their asset class, product type, and minimum market data requirements. `Product` also exposes lightweight nested interfaces such as `RatesProduct`, `FxProduct`, `CreditProduct`, and `MortgageProduct`; these communicate asset-class intent without creating a large product hierarchy.

`MarketDataSnapshot` is the only market data access boundary used by pricers. The demo implementation is `InMemoryMarketDataSnapshot`; there is no database, REST API, queue, or publisher dependency in the core library.

`TradePricer` is the stateless pricing contract. `PricerRegistry` routes each product to the correct pricer. The default registry includes:

- `RatesSwapPricer`
- `FxForwardPricer`
- `CreditDefaultSwapPricer`
- `MortgagePoolPricer`

`DefaultFinancialLibrary` is the top-level orchestration facade. It validates the request, builds pricing context, resolves pricers through the registry, collects trade-level results, and returns normalized valuations.

`CalculationTrace` captures request id, valuation date, market data set id, model version, scenario id, pricer name, and calculation timestamp for auditability. Pricers use its static factory method so trace construction stays consistent.

`Require` centralizes small precondition checks such as non-null values, non-blank text, non-empty sets, defensive list copies, and finite non-zero numbers. It keeps records readable without introducing a heavy validation framework.

## Request And Trade Loading

The request carries `tradeIds` as the execution contract: it identifies the intended portfolio slice and requested measures. The core library still receives fully loaded `Trade` objects from the caller, because trade sourcing is deliberately outside the library boundary. `RequestValidator` checks that requested trade ids were actually loaded and then validates each product's market data requirements before pricing starts.

## Flow

```text
CalculationRequest
  -> caller loads Trade objects and MarketDataSnapshot
  -> RequestValidator validates loaded trades and market data requirements
  -> DefaultFinancialLibrary builds PricingContext
  -> PricerRegistry routes each product to a stateless TradePricer
  -> TradePricer returns PricingResult
  -> DefaultFinancialLibrary normalizes TradeValuation results
  -> CalculationTrace captures lineage
  -> optional ScenarioRiskCalculator / ResultComparator controls
```

## Supported Measures

- `PRESENT_VALUE`
- `DV01`
- `FX_DELTA`
- `CS01`
- `OAS`

The measures are returned where they are relevant to the product type. A portfolio containing all four demo asset classes can return the full requested measure set.

`RiskMeasure` is an enum for readability in the review, but it implements `MeasureDefinition`, which carries a code, display name, description, and supported asset classes. A production version could add new measure definitions or a registry-backed measure catalog without changing the request, pricing, or comparison flow.

## Scenario Risk

`ScenarioRiskCalculator` performs simple bumped PV revaluation. It calculates base PV, applies a market data bump to an in-memory snapshot, revalues the trades, and returns trade-level PV differences for a named scenario. It is an extensibility example, not a full risk infrastructure.

## Regression Comparison

`ResultComparator` compares baseline and candidate `CalculationResult` instances using a numeric tolerance. This is a lightweight control useful for model upgrades, refactoring, and release checks.

## Why This Is Production-Minded

- Immutable request/result models use Java records.
- Pricers are stateless and isolated by product type.
- Asset-class product interfaces express extension points without adding noisy layers.
- Measures have metadata through `MeasureDefinition` while keeping the standard set easy to read.
- Market data is accessed only through `MarketDataSnapshot`.
- Validation failures are explicit and returned before pricing starts.
- Audit trace fields support reproducibility and model governance.
- Scenario risk is implemented through revaluation, keeping pricers simple.
- Regression comparison is included as a first-class engineering control.
- The core library has no database, REST, queue, or vendor dependency.

## Intentionally Out Of Scope

- Full financial model calibration.
- Real curve construction and interpolation.
- Complete product lifecycle events.
- Database persistence.
- REST/gRPC API layer.
- Queue, staging, or publisher implementation.
- Distributed compute and caching.

These concerns can be added around the core contracts without changing the pricing path.
