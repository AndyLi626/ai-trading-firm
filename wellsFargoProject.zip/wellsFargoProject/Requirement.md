
Original requirement：
Design the Architecture for a Production-Grade FinancialLibrary in Java 17+
Your task is to design and build the skeleton of anindustrial-strength financial library in Java. Focus on definingthe core interfaces and architectural structure;implementations should be minimal and included only to
illustrate how components interact.
The library should reflect production-quality design. Youmay decide which production elements and engineeringconsiderations to include. Use your selection of features andabstractions to demonstrate both the breadth and depth ofyour experience.
The primary function of the library is to support valuationand common risk metrics across the following asset classes:Rates, Foreign Exchange (FX), Credit, and Mortgages.
You will not have time to design a complete or fully detailedsystem. Instead, choose the aspects that best showcase yourability to build robust, scalable financial software and yourknowledge of financial instruments and their valuationmethodologies.
Submit your design in code (java, yml, json, MD,..), bundledina zip.
Include a readme.MD to explain the design considerations.

Current code：
目前的文件
README.md
roadmap.md
architecture.yml
sample-calculation-request.json
都是基于公司目前的workflow

Update the current design into a lean, review-ready Java 17 Maven project.

Summarized Goal:
Build a clean-room financial analytics library skeleton that is small, explainable, and production-minded. Do not over-engineer.

Use package:
com.example.finrisk

Core requirements:
1. Support four asset classes: Rates, FX, Credit, Mortgages.
2. Support valuation and common risk measures:
   - PRESENT_VALUE
   - DV01
   - FX_DELTA
   - CS01
   - OAS
3. Use minimal illustrative pricing logic only.
4. Focus on architecture and extensibility, not complete financial modeling.
5. Include validation, audit trace, scenario-based risk, and regression comparison.
6. Keep total Java files around 25–35.
7. The code must compile and tests must pass with Maven.

Recommended package structure:
- api
- domain
- instrument
- market
- pricing
- risk
- validation
- audit

Important design rules:
- Immutable request/result models using Java records where appropriate.
- No company-specific names, no proprietary system names, no internal schemas.
- No database dependency.
- No REST API.
- No queue/staging/publisher implementation in the core submission.
- Use in-memory demo market data.
- Pricers should be stateless.
- Market data should be accessed only through MarketDataSnapshot.
- PricingEngine / DefaultFinancialLibrary should route trades through PricerRegistry.
- ScenarioRiskCalculator should calculate simple bumped risk measures by revaluing with modified market data or scenario context.
- ResultComparator should compare baseline vs candidate results with tolerance.

Tests required:
1. Price a multi-asset portfolio with four demo trades.
2. Verify PricerRegistry routes each product to the correct pricer.
3. Verify requested risk measures are returned.
4. Verify missing market data produces validation failure.
5. Verify ScenarioRiskCalculator can calculate a simple DV01 or CS01 style bumped result.
6. Verify ResultComparator marks differences within and outside tolerance.
7. Verify CalculationTrace contains requestId, valuationDate, marketDataSetId, modelVersion, scenarioId, and pricer name.

README requirements:
- Explain this is a clean-room generic Java 17 financial analytics library.
- Explain core abstractions.
- Explain request -> market data -> pricer registry -> pricing result -> risk result -> trace flow.
- Explain why the design is production-minded.
- Explain what is intentionally out of scope.
- Include commands: mvn test.